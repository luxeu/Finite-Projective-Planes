# A matching obstruction to an order 12 completion

This example is a semiplane with 16 lines, 67 points, and 149 incidences. It passes the numerical conditions in Nation and Seffrood's 2011 algorithm and the current-state required-join screen implemented in this project. Two required joining lines are nevertheless forced to use the same intersection point on a full line. This proves that the semiplane cannot extend to a plane of order 12.

## Necessary matching condition

Let p be a recorded point, and let L and M be selected lines through neither p. Suppose L already contains all n+1 of its points. Let C be any set of recorded points on M, outside L, that currently lack their joining lines with p.

For q in C, let D(q) be the set of recorded points a on L such that neither p,a nor q,a already shares a selected line. In a completion, the required joining line pq must meet L at a point in D(q). The joining lines pq, for different q in C, must be distinct because their q's already share M and p is off M. They must therefore meet L at distinct points.

Consequently, every subset A of C must satisfy

    |union of D(q) for q in A| >= |A|.

This is Hall's necessary condition for a matching. A deficient set A is a rejection certificate. The previous required-join screen checks only that each individual D(q) is nonempty.

If L has c missing points, treating those c places as additional candidates available to every q gives the weaker necessary inequality

    |union of D(q) for q in A| + c >= |A|.

The c places must be included to avoid falsely rejecting configurations whose joining lines could meet L at currently unrepresented points.

## Complete construction

Use the sixteen line names L, M, P1 through P9, and E1 through E5. Prescribe these ten points.

| Point | Incident lines |
| --- | --- |
| p | P1, P2, P3, P4, P5, P6, P7, P8, P9 |
| x | L, M |
| a1 | L, E5 |
| a2 | L, E1, E3 |
| a3 | L, E2, E4 |
| b1 | M, E1, E2 |
| b2 | M, E3, E4 |
| b3 | M, E5 |
| y | P1, E1, E4, E5 |
| z | P2, E2, E3, E5 |

For every pair of lines whose intersection is still unspecified, introduce a separate new point incident with precisely that pair. There are 57 such points. This completely specifies the semiplane without relying on a drawing.

L contains x, a1, a2, a3, and its nine intersections with the Pi. M similarly contains x, b1, b2, b3, and its nine intersections with the Pi. Both lines are full for order 12.

## The contradiction

The missing line p-b1 must meet L. It cannot use any of the nine Pi intersections because those points are already joined to p. It cannot use x, a2, or a3 because those points are already joined to b1 by M, E1, and E2, respectively. Thus it must use a1.

The missing line p-b2 must also use a1. The same exclusions apply, using M, E3, and E4.

The two required lines must be distinct because b1 and b2 already lie on M, which excludes p. They would then share both p and a1. That violates unique intersection. The Hall certificate is simply A={b1,b2} and D(b1)=D(b2)={a1}.

## Checked measurements

| Quantity | Value | Order 12 restriction |
| --- | ---: | ---: |
| Points | 67 | at most 157 |
| Lines | 16 | at most 157 |
| Maximum point degree | 9 | at most 13 |
| Maximum line size | 13 | at most 13 |
| Incidences | 149 | used in the budget |
| rho | 149+157-67-13(16)=31 | at least 0 |

The verifier checks that every pair of lines meets exactly once and every pair of points shares at most one line. It separately reproduces the previous required-join screen using sets. All 1,554 unjoined pairs pass the endpoint capacity test, and all 1,946 applicable pair/full-line checks have at least one compatible intersection.

## Relation to the earlier coloring check

This is also a certificate for our earlier point-allocation rule. The point p has only four future lines available. The five points x, a2, a3, b1, b2 are all unjoined to p and pairwise joined to each other, so they form a K5 in its conflict graph. They require five future lines.

Thus this example establishes that the earlier coloring condition is stronger than the current-state numerical and required-join screens. The matching formulation identifies a restricted family of the clique obstructions already covered by that coloring condition. For any deficient subset on M, its union with the incompatible available points on L gives such an oversized clique.

The existing bounded search from required_join_benchmark.zip also rejects this example after exploring descendants. With its original depth-two and ten-node limits, the baseline visited three nodes, considered three candidate additions, and rejected one candidate numerically and one visited state by the required-join screen. Adding coloring rejected the root in one node. These counts describe this deliberately constructed example.

## Scope

This semiplane is independent of the Class 1 seed used in our previous experiment. Indeed any twelve of these sixteen lines include at least five of the nine lines through p. A Class 1 semiplane has maximum point degree four, so it cannot occur as the semiplane induced by twelve lines here. This example therefore does not eliminate a descendant of that seed.

A separate exploratory scan of the previous 384 general states found no additional matching rejection. Ten sampled known Hall-plane states produced no rejection. The targeted witness and reduced core from the earlier work were rejected again. These observations do not establish a typical-search speedup or novelty in the literature.

## Reproduction

Run `python3 verify.py` with Python 3.10 or later and without `-O`. It uses only the standard library, constructs the complete incidence structure, checks the numerical and required-join screens, verifies the Hall and clique certificates, and writes witness.json. The verification code imports none of the earlier search or coloring modules.

## Source for the comparison

J. B. Nation and J. Y. G. Seffrood, Dual linear spaces generated by a non-Desarguesian configuration, Contributions to Discrete Mathematics 6(1), 2011, especially Sections 3–5.

https://math.hawaii.edu/~jb/planes-cdm.pdf
