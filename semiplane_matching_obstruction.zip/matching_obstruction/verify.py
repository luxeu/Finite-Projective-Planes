#!/usr/bin/env python3
"""Construct and independently verify an order-12 extension obstruction.

Standard library only. All incidence checks use sets. No imports from the
previous semiplane, search, or coloring implementation are used.
"""
import json
from itertools import combinations
from pathlib import Path

ORDER = 12
LINES = ('L', 'M', *(f'P{i}' for i in range(1, 10)),
         *(f'E{i}' for i in range(1, 6)))
SPECIAL_POINTS = {
    'p': {f'P{i}' for i in range(1, 10)},
    'x': {'L', 'M'},
    'a1': {'L', 'E5'},
    'a2': {'L', 'E1', 'E3'},
    'a3': {'L', 'E2', 'E4'},
    'b1': {'M', 'E1', 'E2'},
    'b2': {'M', 'E3', 'E4'},
    'b3': {'M', 'E5'},
    'y': {'P1', 'E1', 'E4', 'E5'},
    'z': {'P2', 'E2', 'E3', 'E5'},
}


def build():
    points = {point: set(lines) for point, lines in SPECIAL_POINTS.items()}
    for first, second in combinations(LINES, 2):
        existing = [point for point, support in points.items()
                    if first in support and second in support]
        assert len(existing) <= 1
        if not existing:
            points[f'q_{first}_{second}'] = {first, second}
    return points


def verify(points):
    on_line = {line: {point for point, support in points.items() if line in support}
               for line in LINES}
    assert all(len(support) >= 2 for support in points.values())
    assert all(len(on_line[first] & on_line[second]) == 1
               for first, second in combinations(LINES, 2))
    assert all(len(points[first] & points[second]) <= 1
               for first, second in combinations(points, 2))

    incidences = sum(map(len, points.values()))
    rho = incidences + ORDER**2 + ORDER + 1 - len(points) - (ORDER + 1)*len(LINES)
    maximum_degree = max(map(len, points.values()))
    maximum_line_size = max(map(len, on_line.values()))
    assert len(points) <= ORDER**2 + ORDER + 1
    assert len(LINES) <= ORDER**2 + ORDER + 1
    assert maximum_degree <= ORDER + 1
    assert maximum_line_size <= ORDER + 1
    assert rho >= 0

    # Independent reproduction of the previous required-join screen for EVERY
    # unjoined pair and EVERY full line through neither endpoint.
    full_lines = [line for line in LINES if len(on_line[line]) == ORDER + 1]
    unjoined_pairs = 0
    full_line_checks = 0
    for first, second in combinations(points, 2):
        if points[first] & points[second]:
            continue
        unjoined_pairs += 1
        assert len(points[first]) < ORDER + 1
        assert len(points[second]) < ORDER + 1
        for line in full_lines:
            if line in points[first] or line in points[second]:
                continue
            full_line_checks += 1
            candidates = {point for point in on_line[line]
                          if not points[point] & points[first]
                          and not points[point] & points[second]}
            assert candidates, (first, second, line)

    # The two future joins p-b1 and p-b2 must be distinct because b1 and b2
    # already lie on M. Both are forced to meet L at a1.
    assert not points['p'] & points['b1']
    assert not points['p'] & points['b2']
    assert points['b1'] & points['b2'] == {'M'}
    assert 'M' not in points['p']
    domains = {}
    for point in ('b1', 'b2'):
        domains[point] = sorted(candidate for candidate in on_line['L']
                                if not points[candidate] & points['p']
                                and not points[candidate] & points[point])
    assert domains == {'b1': ['a1'], 'b2': ['a1']}
    assert len(set().union(*(set(domain) for domain in domains.values()))) < len(domains)

    # The equivalent certificate for our earlier point-allocation test.
    clique = ['x', 'a2', 'a3', 'b1', 'b2']
    assert all(not points['p'] & points[point] for point in clique)
    assert all(points[first] & points[second] for first, second in combinations(clique, 2))
    remaining_lines_at_p = ORDER + 1 - len(points['p'])
    assert len(clique) > remaining_lines_at_p

    # This is independent of Class 1. A subset of 12 of these 16 lines contains
    # at least five of the nine P_i. Its point p has degree at least five,
    # whereas Class 1 has maximum point degree four.
    assert 12 - (len(LINES) - len(points['p'])) == 5

    return {
        'order': ORDER, 'points': len(points), 'lines': len(LINES),
        'incidences': incidences, 'rho': rho,
        'maximum_point_degree': maximum_degree,
        'maximum_line_size': maximum_line_size,
        'line_sizes': {line: len(on_line[line]) for line in LINES},
        'unjoined_pairs_passing_endpoint_check': unjoined_pairs,
        'full_line_checks_passing': full_line_checks,
        'numerical_checks_pass': True,
        'previous_required_join_screen_passes': True,
        'matching_domains': domains,
        'matching_deficiency': 1,
        'equivalent_clique': clique,
        'remaining_lines_at_p': remaining_lines_at_p,
        'contains_class_1_as_a_line_induced_semiplane': False,
    }


if __name__ == '__main__':
    points = build()
    result = verify(points)
    directory = Path(__file__).resolve().parent
    (directory / 'witness.json').write_text(json.dumps({
        'lines': list(LINES),
        'point_to_lines': {point: sorted(support) for point, support in points.items()},
        'verification': result,
    }, indent=2) + '\n')
    print(json.dumps(result, indent=2))
