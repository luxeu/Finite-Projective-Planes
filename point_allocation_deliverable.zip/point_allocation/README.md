# Point-allocation check: second deliverable

Implemented and validated a necessary condition for extending a semiplane to an
order-n projective plane. Found a certified order-12 rejection after six added
lines from Nation--Seffrood configuration #1. The 18-line, 71-point descendant
passes all the previous numerical checks. Its point-allocation obstruction is
a five-vertex clique with only four available lines through its center.

The rejection is deliberately constructed. A separate fixed sample of 384
deeper states yielded no additional rejection within the solver's bounds;
38 of those states remain unresolved by the bounded test.

## Reproduce

Python 3.10 or later; no external packages or network required. Run without
`-O`, because verification uses assertions.

```bash
python3 experiment.py
python3 audit_results.py
python3 make_report.py
```

The experiment takes approximately a minute on the original runtime. Counts
and generated states are deterministic. Wall-clock timings vary by machine.
It overwrites the generated experiment results. The existing first-deliverable
report and files are separate and are not overwritten.

The exact coloring search and clique search each have a separate 3,000-node
limit per point. Exhausting a limit never proves an impossibility: it produces
`unknown` unless another point supplies a complete rejection certificate.
`passes_local_test` is also only a necessary-condition result.

## Files

| File | Purpose |
| --- | --- |
| `POINT_ALLOCATION_REPORT.md` | Rule, proof, explicit rejection, full benchmark results and limits |
| `allocation.py` | Conflict-graph construction; greedy coloring; clique certificates; bounded exact coloring with exhaustion proofs |
| `certificate_check.py` | Independent set-based checker; imports no allocation solver |
| `experiment.py` | Positive controls, targeted construction, general-branch generation and benchmark |
| `audit_results.py` | Checks all saved states, certificates and branch provenance independently |
| `make_report.py` | Builds the report from the computed results |
| `seed1.py` | Reused first-deliverable geometry and seed code; imported by the experiment |
| `results/target_witness.json` | Standalone 18-line descendant, all six additions, five-point certificate and pairwise joining lines |
| `results/reduced_core.json` | 14-line core, its certificate, and mapping to original line labels |
| `results/corpus.json` | All 1,020 states, including the reduced core |
| `results/benchmark.csv` | Individual statuses, node counts and timings |
| `results/certificates.json` | All negative certificates, keyed by state ID |
| `results/summary.json` | Counts, timing totals and declared limits |
| `results/audit_summary.json` | Independent audit results |
| `results/target_trace.json` | Six-step construction from configuration #1 |
| `results/general_trace.json` | Baseline-only sample-generation provenance |
| `data/first_orbits.csv` | All 548 first-layer representatives from the first deliverable |
| `data/hall9.txt` | G. Eric Moorhouse's numerical Hall(9) incidence data |
| `data/hall9_trace.json` | Previously checked seed embedding and 79-line completion trace |
| `SHA256SUMS.txt` | Checksums for the delivered files |

`seed1.py` is a dependency copied from the first deliverable; use the three
commands above to reproduce this experiment. Names `p1` through `p10` follow
Nation and Seffrood; a seed point `qi_j` is the intersection of `li` and `lj`.
Fresh point `qk_i` in a trace is the intersection of local line `lk` with `li`.

## Provenance

- Starting configuration: Nation and Seffrood, *Dual linear spaces generated
  by a non-Desarguesian configuration* (2011), Table 2 and Appendix class 1:
  https://math.hawaii.edu/~jb/planes-cdm.pdf
- Known-plane numerical data: G. Eric Moorhouse,
  https://ericmoorhouse.org/pub/planes/hall9.txt
- Geometry, seed and first-layer representatives were reused from the first
  deliverable. New experiment code, rule formulation, witness and calculations
  are supplied here. No literature-novelty claim is made.
