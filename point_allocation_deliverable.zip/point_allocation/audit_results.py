#!/usr/bin/env python3
"""Audit stored states, branch provenance and all negative certificates.

This audit does not import the allocation solver. It uses the separate
set-based checker and direct incidence comparisons with the Hall(9) data.
"""
import csv
import json
from collections import Counter
from itertools import combinations
from pathlib import Path
from certificate_check import check_structure_and_baseline, verify_certificate

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"


def verify_extension(before, after, selected=None):
    old_count = before["line_count"]
    assert after["line_count"] == old_count + 1
    old_mask = (1 << old_count) - 1
    new_bit = 1 << old_count
    a = dict(zip(before["labels"], before["supports"]))
    b = dict(zip(after["labels"], after["supports"]))
    assert a.keys() <= b.keys()
    assert all(b[name] & old_mask == support for name, support in a.items())
    chosen = {name for name in a if b[name] & new_bit}
    if selected is not None:
        assert set(selected) == chosen
    assert all(not a[x] & a[y] for x, y in combinations(chosen, 2))
    covered = 0
    for name in chosen:
        covered |= a[name]
    fresh_supports = [b[name] for name in b.keys() - a.keys()]
    assert all(s & new_bit and (s & old_mask).bit_count() == 1 for s in fresh_supports)
    expected = {new_bit | (1 << j) for j in range(old_count) if not covered & (1 << j)}
    assert set(fresh_supports) == expected
    assert len(fresh_supports) == len(expected)


def main():
    corpus = json.loads((OUT / "corpus.json").read_text())
    by_id = {x["id"]: x for x in corpus}
    assert len(by_id) == len(corpus)
    certificates = json.loads((OUT / "certificates.json").read_text())
    ledger = list(csv.DictReader((OUT / "benchmark.csv").open()))
    summary = json.loads((OUT / "summary.json").read_text())
    for entry in corpus:
        check_structure_and_baseline(entry["state"], entry["order"])
    for key, cert in certificates.items():
        entry = by_id[key]
        verify_certificate(entry["state"], entry["order"], cert)
    for row in ledger:
        assert row["baseline_status"] == "passes_necessary_checks"
        if row["allocation_status"] == "rejected":
            assert row["id"] in certificates
        else:
            assert row["allocation_status"] in ("passes_local_test", "unknown")
            assert row["id"] not in certificates
    for cohort, stats in summary["benchmark"].items():
        rows = [x for x in ledger if x["cohort"] == cohort]
        assert len(rows) == stats["states"]
        assert dict(Counter(x["allocation_status"] for x in rows)) == stats["statuses"]
    assert len(certificates) == summary["total_certificates_including_core"]
    witness = json.loads((OUT / "target_witness.json").read_text())
    assert witness["state"] == by_id["target_06"]["state"]
    assert witness["certificate"] == certificates["target_06"]
    for edge in witness["pair_line_witnesses"]:
        p, q = edge["points"]
        supports = dict(zip(witness["state"]["labels"], witness["state"]["supports"]))
        j = int(edge["existing_line"][1:]) - 1
        assert supports[p] & supports[q] & (1 << j)
    core = json.loads((OUT / "reduced_core.json").read_text())
    assert core["state"] == by_id["reduced_core"]["state"]
    verify_certificate(core["state"], 12, core["certificate"])

    target_trace = json.loads((OUT / "target_trace.json").read_text())
    for i, step in enumerate(target_trace, 1):
        verify_extension(by_id[f"target_{i-1:02}"]["state"], by_id[f"target_{i:02}"]["state"],
                         step["selected_points"])
    initial = by_id["target_00"]["state"]
    for entry in corpus:
        if entry["cohort"] == "first_layer":
            verify_extension(initial, entry["state"])
    general_trace = json.loads((OUT / "general_trace.json").read_text())
    previous = {}
    for row in general_trace:
        if row["status"] != "accepted_by_baseline":
            continue
        before = previous.get(row["branch"], by_id[row["root"]]["state"])
        after = by_id[row["state_id"]]["state"]
        verify_extension(before, after, row["selected_points"])
        previous[row["branch"]] = after

    point_lines = [set(map(int, row.split())) for row in (ROOT / "data" / "hall9.txt").read_text().splitlines()]
    line_points = [{p for p, lines in enumerate(point_lines) if line in lines} for line in range(91)]
    assert all(len(a & b) == 1 for a, b in combinations(line_points, 2))
    assert all(len(a & b) == 1 for a, b in combinations(point_lines, 2))
    trace = json.loads((ROOT / "data" / "hall9_trace.json").read_text())
    point_map = dict(trace["seed_point_embedding"])
    selected_lines = [trace["seed_line_embedding"][f"l{i+1}"] for i in range(12)]
    for stage in range(80):
        state = by_id[f"hall_{stage:02}"]["state"]
        for name, support in zip(state["labels"], state["supports"]):
            expected = sum(1 << j for j, line in enumerate(selected_lines)
                           if point_map[name] in line_points[line])
            assert support == expected
        if stage == 79:
            break
        following = by_id[f"hall_{stage+1:02}"]["state"]
        step = trace["steps"][stage]
        verify_extension(state, following, step["existing_points_selected"])
        hall_line = step["hall_line"]
        known = set(point_map.values())
        for j, old_line in enumerate(selected_lines):
            hp, = line_points[old_line] & line_points[hall_line]
            if hp not in known:
                point_map[f"q{len(selected_lines)+1}_{j+1}"] = hp
        selected_lines.append(hall_line)
    assert len(point_map) == len(set(point_map.values())) == 91
    assert len(selected_lines) == len(set(selected_lines)) == 91
    result = {"states_independently_validated": len(corpus),
              "negative_certificates_independently_verified": len(certificates),
              "all_target_and_general_extension_steps_checked": True,
              "all_first_layer_representatives_checked": True,
              "hall9_80_states_compared_with_full_plane": True,
              "allocation_solver_imported": False}
    (OUT / "audit_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
