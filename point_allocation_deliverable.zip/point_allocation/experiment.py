#!/usr/bin/env python3
"""Reproducible implementation, positive controls, witness and fixed benchmark."""
from __future__ import annotations
import csv
import hashlib
import json
import random
from collections import Counter
from dataclasses import asdict
from itertools import combinations, product
from pathlib import Path
from time import perf_counter

from seed1 import Semiplane, build_seed, rejection_reasons
from allocation import (ConflictGraph, check_state, conflict_graph, exact_coloring,
                        verify_coloring)
from certificate_check import check_structure_and_baseline, verify_certificate, verify_exhaustion

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
NODE_LIMIT = 3000
CLIQUE_LIMIT = 3000
TARGET_GROUPS = (("q4_8", "q5_7"), ("q4_9", "q5_10"),
                 ("q5_9", "q6_8"), ("q6_7", "q8_10"),
                 ("q6_11",), ("q9_11",))


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def encode(state):
    return {"labels": list(state.labels), "supports": list(state.supports),
            "line_count": state.line_count}


def state_from(raw):
    return Semiplane(tuple(raw["labels"]), tuple(raw["supports"]), raw["line_count"])


def small_graph_validation():
    cases = 0
    proofs = 0
    for n in range(1, 6):
        pairs = list(combinations(range(n), 2))
        for edge_mask in range(1 << len(pairs)):
            adjacency = [0] * n
            neighbors = [set() for _ in range(n)]
            for i, (a, b) in enumerate(pairs):
                if edge_mask & (1 << i):
                    adjacency[a] |= 1 << b
                    adjacency[b] |= 1 << a
                    neighbors[a].add(b)
                    neighbors[b].add(a)
            for slots in range(1, min(n, 3) + 1):
                capacities = range(1, n + 1) if n <= 4 else (n,)
                for capacity in capacities:
                    graph = ConflictGraph(0, tuple(range(n)), tuple(adjacency), slots, capacity)
                    brute = any(all(colors.count(c) <= capacity for c in set(colors))
                                and all(colors[a] != colors[b] for a, b in pairs
                                        if b in neighbors[a])
                                for colors in product(range(slots), repeat=n))
                    answer = exact_coloring(graph, 100000)
                    assert answer["status"] == ("colorable" if brute else "uncolorable")
                    if brute:
                        assert verify_coloring(graph, answer["coloring"])
                    else:
                        verify_exhaustion(neighbors, slots, capacity, answer["proof"])
                        proofs += 1
                    cases += 1
    # A five-cycle needs three colors but has no triangle; exercises non-clique exhaustion.
    cycle = ConflictGraph(0, tuple(range(5)), (18, 5, 10, 20, 9), 2, 5)
    assert exact_coloring(cycle, 1)["status"] == "unknown"
    answer = exact_coloring(cycle, 10000)
    assert answer["status"] == "uncolorable"
    neighbors = [{j for j in range(5) if mask & (1 << j)} for mask in cycle.adjacency]
    verify_exhaustion(neighbors, 2, 5, answer["proof"])
    return {"brute_force_comparison_cases": cases, "exhaustion_proofs_checked": proofs,
            "five_cycle_nonclique_obstruction_checked": True,
            "node_limit_returns_unknown_checked": True}


def target_branch(seed):
    states = [("target_00", seed)]
    trace = []
    current = seed
    for step, group in enumerate(TARGET_GROUPS, 1):
        names = ["p7", *group]
        current, uncovered = current.add_line([current.labels.index(name) for name in names])
        current.validate()
        assert not rejection_reasons(current, 12)
        trace.append({"step": step, "selected_points": names,
                      "uncovered_old_lines": [f"l{i + 1}" for i in uncovered],
                      **check_structure_and_baseline(encode(current), 12)})
        states.append((f"target_{step:02}", current))
    return states, trace


def hall_states(seed):
    raw = (ROOT / "data" / "hall9.txt").read_bytes()
    point_lines = [set(map(int, row.split())) for row in raw.splitlines()]
    trace = json.loads((ROOT / "data" / "hall9_trace.json").read_text())
    assert hashlib.sha256(raw).hexdigest() == trace["data_sha256"]
    current = seed
    mapping = dict(trace["seed_point_embedding"])
    selected_lines = [trace["seed_line_embedding"][f"l{i + 1}"] for i in range(12)]
    line_points = [{p for p, row in enumerate(point_lines) if line in row} for line in range(91)]
    assert all(len(x) == 10 for x in point_lines + line_points)
    assert all(len(a & b) == 1 for a, b in combinations(line_points, 2))
    assert all(len(a & b) == 1 for a, b in combinations(point_lines, 2))
    states = []
    known_assignments = 0
    for stage in range(80):
        current.validate()
        assert not rejection_reasons(current, 9)
        for p, name in enumerate(current.labels):
            graph = conflict_graph(current, p, 9)
            future = sorted(point_lines[mapping[name]] - set(selected_lines))
            colors = []
            for q in graph.vertices:
                full_join, = point_lines[mapping[name]] & point_lines[mapping[current.labels[q]]]
                colors.append(future.index(full_join))
            assert verify_coloring(graph, colors)
            known_assignments += 1
        states.append((f"hall_{stage:02}", current))
        if stage == 79:
            break
        step = trace["steps"][stage]
        chosen = [current.labels.index(x) for x in step["existing_points_selected"]]
        following, uncovered = current.add_line(chosen)
        hall_line = step["hall_line"]
        for j in uncovered:
            hp, = line_points[selected_lines[j]] & line_points[hall_line]
            mapping[f"q{current.line_count + 1}_{j + 1}"] = hp
        selected_lines.append(hall_line)
        current = following
    return states, {"states": len(states), "actual_future_line_assignments_checked": known_assignments,
                    "final_points": len(current.labels), "final_lines": current.line_count,
                    "source": "https://ericmoorhouse.org/pub/planes/hall9.txt"}


def first_representatives(seed):
    rows = list(csv.DictReader((ROOT / "data" / "first_orbits.csv").open()))
    states = []
    for row in rows:
        selected = [seed.labels.index(x) for x in row["representative_points"].split()]
        state, _ = seed.add_line(selected)
        state.validate()
        states.append(("first_" + row["orbit_id"], state))
    assert len(states) == 548
    return states


def general_branches(first):
    """Generate a corpus using baseline checks only, before applying allocation.

    Thirty-two randomly chosen first-layer representatives. A shuffled greedy
    compatible set supplies each proposal; all compatible points are selected
    in that shuffle order. At most 128 proposals per stage and 12 further lines.
    Exhausting a proposal budget is not a branch impossibility result.
    """
    rng = random.Random(2026111002)
    starts = rng.sample(first, 32)
    states = []
    trace_rows = []
    reasons = Counter()
    proposals = 0
    stalled = 0
    for branch, (root_id, root) in enumerate(starts, 1):
        current = root
        path = []
        for depth in range(1, 13):
            accepted = None
            for attempt in range(1, 129):
                proposals += 1
                order = list(range(len(current.labels)))
                rng.shuffle(order)
                selected, covered = [], 0
                for q in order:
                    if not covered & current.supports[q]:
                        selected.append(q)
                        covered |= current.supports[q]
                assert len(selected) >= 2
                following, _ = current.add_line(selected)
                failed = rejection_reasons(following, 12)
                if failed:
                    reasons.update(failed)
                    continue
                accepted = following
                selected_names = [current.labels[q] for q in selected]
                path.append(selected_names)
                break
            if accepted is None:
                stalled += 1
                trace_rows.append({"branch": branch, "root": root_id, "status": "proposal_budget_exhausted",
                                   "lines_reached": current.line_count})
                break
            current = accepted
            current.validate()
            state_id = f"general_{branch:02}_{depth:02}"
            states.append((state_id, current))
            trace_rows.append({"branch": branch, "root": root_id, "state_id": state_id,
                               "status": "accepted_by_baseline", "proposal_at_stage": attempt,
                               "selected_points": selected_names, "lines": current.line_count})
    return states, trace_rows, {"random_seed": 2026111002, "starting_representatives": 32,
              "max_further_lines": 12, "max_proposals_per_stage": 128,
              "proposals": proposals, "baseline_rejection_reason_counts": dict(reasons),
              "stalled_branches": stalled, "states_retained": len(states),
              "generation_uses_allocation_test": False}


def restricted_core(state, certificate):
    center = state.labels.index(certificate["center"])
    selected = set(j for j in range(state.line_count) if state.supports[center] & (1 << j))
    witnesses = [state.labels.index(x) for x in certificate["vertices"]]
    for a, b in combinations(witnesses, 2):
        common = state.supports[a] & state.supports[b]
        assert common.bit_count() == 1
        selected.add(common.bit_length() - 1)
    selected = sorted(selected)
    labels, supports = [], []
    for name, support in zip(state.labels, state.supports):
        new_support = sum(1 << i for i, j in enumerate(selected) if support & (1 << j))
        if new_support.bit_count() >= 2:
            labels.append(name)
            supports.append(new_support)
    core = Semiplane(tuple(labels), tuple(supports), len(selected))
    core.validate()
    assert not rejection_reasons(core, 12)
    verify_certificate(encode(core), 12, certificate)
    # This particular clique certificate disappears after any one core line is deleted.
    deletion_checks = []
    for omitted in range(core.line_count):
        retained = [i for i in range(core.line_count) if i != omitted]
        entries = [(name, sum(1 << k for k, i in enumerate(retained) if s & (1 << i)))
                   for name, s in zip(core.labels, core.supports)]
        deleted = Semiplane(tuple(name for name, s in entries if s.bit_count() >= 2),
                            tuple(s for name, s in entries if s.bit_count() >= 2), len(retained))
        try:
            verify_certificate(encode(deleted), 12, certificate)
        except (AssertionError, KeyError):
            deletion_checks.append(True)
        else:
            deletion_checks.append(False)
    assert all(deletion_checks)
    return core, {"retained_original_lines": [f"l{i + 1}" for i in selected],
                  "line_deletion_minimal_for_this_certificate": True,
                  "contains_the_full_seed": False,
                  **check_structure_and_baseline(encode(core), 12)}


def run():
    OUT.mkdir(parents=True, exist_ok=True)
    start = perf_counter()
    validation = small_graph_validation()
    print("Small-graph solver and proof validation passed", flush=True)
    seed = build_seed()
    target, target_trace = target_branch(seed)
    first = first_representatives(seed)
    hall, hall_validation = hall_states(seed)
    general, general_trace, generation = general_branches(first)
    print(f"Corpus generated: {len(first)} first-layer, {len(hall)} Hall, {len(general)} general states", flush=True)
    corpus = []
    ledger = []
    certificates = {}
    for cohort, items, order in [("targeted", target, 12), ("first_layer", first, 12),
                                  ("hall9", hall, 9), ("general", general, 12)]:
        for index, (state_id, state) in enumerate(items):
            baseline_start = perf_counter()
            baseline = rejection_reasons(state, order)
            baseline_seconds = perf_counter() - baseline_start
            assert not baseline
            test_start = perf_counter()
            result = check_state(state, order, NODE_LIMIT, CLIQUE_LIMIT)
            test_seconds = perf_counter() - test_start
            if cohort == "hall9":
                assert result["status"] != "rejected"
            encoded = encode(state)
            if result["status"] == "rejected":
                check_structure_and_baseline(encoded, order)
                verify_certificate(encoded, order, result["certificate"])
                certificates[state_id] = result["certificate"]
            corpus.append({"id": state_id, "cohort": cohort, "order": order, "state": encoded})
            ledger.append({"id": state_id, "cohort": cohort, "order": order,
                           "points": len(state.labels), "lines": state.line_count,
                           "rho": state.rho(order), "baseline_status": "passes_necessary_checks",
                           "allocation_status": result["status"], "centers_checked": result["centers_checked"],
                           "search_nodes": result["nodes"],
                           "certificate_kind": result.get("certificate", {}).get("kind", ""),
                           "baseline_seconds": baseline_seconds, "allocation_seconds": test_seconds})
            if index and index % 100 == 0:
                print(f"{cohort}: {index}/{len(items)} checked", flush=True)
        print(f"{cohort} complete", flush=True)
    target_id = "target_06"
    assert certificates[target_id]["kind"] == "clique"
    core, core_info = restricted_core(target[-1][1], certificates[target_id])
    corpus.append({"id": "reduced_core", "cohort": "reduced_core", "order": 12, "state": encode(core)})
    certificates["reduced_core"] = certificates[target_id]
    stats = {}
    for cohort in ("targeted", "first_layer", "hall9", "general"):
        rows = [x for x in ledger if x["cohort"] == cohort]
        stats[cohort] = {"states": len(rows), "statuses": dict(Counter(x["allocation_status"] for x in rows)),
                         "certificate_kinds": dict(Counter(x["certificate_kind"] for x in rows if x["certificate_kind"])),
                         "baseline_seconds": sum(x["baseline_seconds"] for x in rows),
                         "allocation_seconds": sum(x["allocation_seconds"] for x in rows),
                         "max_lines": max(x["lines"] for x in rows)}
    write_json("corpus.json", corpus)
    write_json("certificates.json", certificates)
    write_json("target_trace.json", target_trace)
    write_json("general_trace.json", general_trace)
    witness = target[-1][1]
    proof_vertices = certificates[target_id]["vertices"]
    edge_witnesses = []
    for a, b in combinations(proof_vertices, 2):
        common = witness.supports[witness.labels.index(a)] & witness.supports[witness.labels.index(b)]
        assert common.bit_count() == 1
        edge_witnesses.append({"points": [a, b], "existing_line": f"l{common.bit_length()}"})
    write_json("target_witness.json", {"state": encode(witness), "trace": target_trace,
              "certificate": certificates[target_id], "pair_line_witnesses": edge_witnesses})
    write_json("reduced_core.json", {"state": encode(core), "certificate": certificates[target_id],
                                    "details": core_info})
    with (OUT / "benchmark.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(ledger[0]))
        writer.writeheader()
        writer.writerows(ledger)
    summary = {"solver_node_limit_per_point": NODE_LIMIT, "clique_node_limit_per_point": CLIQUE_LIMIT,
               "small_graph_validation": validation, "hall9_validation": hall_validation,
               "general_generation": generation, "benchmark": stats,
               "target_witness": {"id": target_id, **check_structure_and_baseline(encode(target[-1][1]), 12),
                    "certificate": certificates[target_id]}, "reduced_core": core_info,
               "total_certificates_including_core": len(certificates),
               "elapsed_seconds": perf_counter() - start,
               "scope": "Point-allocation feasibility only; all bounds are necessary, not sufficient for plane completion.",
               "limitations": ["General branches are a finite heuristic sample, not exhaustive deeper coverage.",
                  "The targeted witness is deliberately designed to expose the test and does not estimate typical pruning.",
                  "A node-limit result is unknown and never rejects.",
                  "No novelty or end-to-end search-speedup claim is made.",
                  "The reduced core no longer contains the full 12-line seed."]}
    write_json("summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    run()
