"""Sound bounded point-allocation test. No third-party dependencies.

A return value of 'unknown' never rejects a state. A 'colorable' local graph
is a necessary-condition success, not a proof of plane completion.
"""
from dataclasses import dataclass
from itertools import combinations
from seed1 import bits


@dataclass(frozen=True)
class ConflictGraph:
    center: int
    vertices: tuple[int, ...]
    adjacency: tuple[int, ...]
    slots: int
    capacity: int


def conflict_graph(state, center, order):
    p_support = state.supports[center]
    vertices = tuple(q for q, support in enumerate(state.supports)
                     if not p_support & support)
    adjacency = [0] * len(vertices)
    for i, j in combinations(range(len(vertices)), 2):
        if state.supports[vertices[i]] & state.supports[vertices[j]]:
            adjacency[i] |= 1 << j
            adjacency[j] |= 1 << i
    return ConflictGraph(center, vertices, tuple(adjacency),
                         order + 1 - p_support.bit_count(), order)


def verify_coloring(graph, colors):
    if len(colors) != len(graph.vertices):
        return False
    if any(c < 0 or c >= graph.slots for c in colors):
        return False
    if any(colors.count(c) > graph.capacity for c in set(colors)):
        return False
    return all(colors[i] != colors[j] for i, neighbors in enumerate(graph.adjacency)
               for j in bits(neighbors) if i < j)


def greedy_coloring(graph):
    n = len(graph.vertices)
    if n == 0:
        return ()
    if graph.slots <= 0:
        return None
    colors = [-1] * n
    saturation = [0] * n
    loads = [0] * graph.slots
    remaining = set(range(n))
    used = 0
    while remaining:
        v = max(remaining, key=lambda x: (saturation[x].bit_count(),
                                         graph.adjacency[x].bit_count(), -x))
        available = [c for c in range(used) if not saturation[v] & (1 << c)
                     and loads[c] < graph.capacity]
        if not available and used < graph.slots:
            available = [used]
            used += 1
        if not available:
            return None
        c = available[0]
        colors[v] = c
        loads[c] += 1
        remaining.remove(v)
        for q in bits(graph.adjacency[v]):
            if q in remaining:
                saturation[q] |= 1 << c
    assert verify_coloring(graph, colors)
    return tuple(colors)


def find_clique(graph, target, node_limit):
    """Find a clique certificate; not finding one says nothing about coloring."""
    nodes = 0
    def visit(candidates, chosen):
        nonlocal nodes
        nodes += 1
        if nodes > node_limit:
            return None
        if len(chosen) >= target:
            return chosen
        while len(chosen) + candidates.bit_count() >= target:
            v = max(bits(candidates), key=lambda x: (graph.adjacency[x] & candidates).bit_count())
            candidates &= ~(1 << v)
            answer = visit(candidates & graph.adjacency[v], chosen + (v,))
            if answer is not None:
                return answer
            if nodes >= node_limit:
                break
        return None
    return visit((1 << len(graph.vertices)) - 1, ()), nodes


def exact_coloring(graph, node_limit):
    """Bounded DSATUR. Exhaustion returns a fully checkable branching proof.

    Unused colors are interchangeable, so only the next unused color is tried.
    The proof checker verifies coverage of every permissible occupied color
    and that one representative unused color, at every search node.
    """
    n = len(graph.vertices)
    colors = [-1] * n
    loads = [0] * max(0, graph.slots)
    saturation = [0] * n
    remaining = set(range(n))
    nodes = 0
    solution = None
    def visit(used):
        nonlocal nodes, solution
        nodes += 1
        if nodes > node_limit:
            return "unknown", None
        if not remaining:
            solution = tuple(colors)
            return "colorable", None
        v = max(remaining, key=lambda x: (saturation[x].bit_count(),
                                         graph.adjacency[x].bit_count(), -x))
        available = [c for c in range(used) if not saturation[v] & (1 << c)
                     and loads[c] < graph.capacity]
        if used < graph.slots:
            available.append(used)
        children = []
        remaining.remove(v)
        for c in available:
            colors[v] = c
            loads[c] += 1
            changed = []
            for q in bits(graph.adjacency[v]):
                if q in remaining and not saturation[q] & (1 << c):
                    saturation[q] |= 1 << c
                    changed.append(q)
            status, proof = visit(max(used, c + 1))
            for q in changed:
                saturation[q] &= ~(1 << c)
            loads[c] -= 1
            colors[v] = -1
            if status != "uncolorable":
                remaining.add(v)
                return status, None
            children.append({"color": c, "proof": proof})
        remaining.add(v)
        return "uncolorable", {"vertex": v, "children": children}
    status, proof = visit(0)
    if status == "colorable":
        assert verify_coloring(graph, solution)
    return {"status": status, "proof": proof, "coloring": solution, "nodes": nodes}


def check_point(state, center, order, node_limit=3000, clique_node_limit=3000):
    graph = conflict_graph(state, center, order)
    common = {"center": state.labels[center], "slots": graph.slots,
              "unjoined_points": len(graph.vertices)}
    if len(graph.vertices) > max(0, graph.slots) * order:
        return dict(common, status="rejected", certificate={
            "kind": "capacity", "center": common["center"],
            "vertices": [state.labels[q] for q in graph.vertices]}, nodes=0)
    colors = greedy_coloring(graph)
    if colors is not None:
        return dict(common, status="passes_local_test", nodes=0)
    clique, clique_nodes = find_clique(graph, graph.slots + 1, clique_node_limit)
    if clique is not None:
        return dict(common, status="rejected", certificate={
            "kind": "clique", "center": common["center"],
            "vertices": [state.labels[graph.vertices[i]] for i in clique]}, nodes=clique_nodes)
    answer = exact_coloring(graph, node_limit)
    result = dict(common, status={"colorable": "passes_local_test",
                                 "uncolorable": "rejected", "unknown": "unknown"}[answer["status"]],
                  nodes=clique_nodes + answer["nodes"])
    if answer["status"] == "uncolorable":
        result["certificate"] = {"kind": "coloring_exhaustion", "center": common["center"],
                                 "vertices": [state.labels[q] for q in graph.vertices],
                                 "proof": answer["proof"]}
    return result


def check_state(state, order, node_limit=3000, clique_node_limit=3000):
    """Stop on first certified rejection; otherwise preserve all unknowns."""
    unknown = []
    nodes = 0
    centers = sorted(range(len(state.labels)), key=lambda p: (-state.supports[p].bit_count(), p))
    for i, p in enumerate(centers):
        result = check_point(state, p, order, node_limit, clique_node_limit)
        nodes += result["nodes"]
        if result["status"] == "rejected":
            return {"status": "rejected", "certificate": result["certificate"],
                    "centers_checked": i + 1, "nodes": nodes}
        if result["status"] == "unknown":
            unknown.append(result["center"])
    return {"status": "unknown" if unknown else "passes_local_test",
            "unknown_centers": unknown, "centers_checked": len(centers), "nodes": nodes}
