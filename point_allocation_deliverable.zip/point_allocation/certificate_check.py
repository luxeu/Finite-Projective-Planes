"""Independent rejection-certificate verifier, using sets of line labels.

Does not import allocation.py or its graph-construction/solving routines.
"""
from collections import Counter
from itertools import combinations


def point_lines(state):
    return {name: {j for j in range(state["line_count"]) if mask & (1 << j)}
            for name, mask in zip(state["labels"], state["supports"])}


def check_structure_and_baseline(state, order):
    pts = point_lines(state)
    assert len(pts) == len(state["labels"]) == len(state["supports"])
    lines = [{p for p, support in pts.items() if j in support}
             for j in range(state["line_count"])]
    assert all(len(s) >= 2 for s in pts.values())
    assert all(len(a & b) == 1 for a, b in combinations(lines, 2))
    incidence = sum(map(len, lines))
    rho = incidence + order * order + order + 1 - len(pts) - (order + 1) * len(lines)
    assert len(pts) <= order * order + order + 1
    assert len(lines) <= order * order + order + 1
    assert max(map(len, pts.values())) <= order + 1
    assert max(map(len, lines)) <= order + 1
    assert rho >= 0
    return {"points": len(pts), "lines": len(lines), "incidences": incidence,
            "max_point_degree": max(map(len, pts.values())),
            "max_line_size": max(map(len, lines)), "rho": rho}


def verify_exhaustion(neighbors, slots, capacity, proof):
    colors = {}
    loads = Counter()
    nodes = 0
    def visit(node, used):
        nonlocal nodes
        nodes += 1
        v = node["vertex"]
        assert 0 <= v < len(neighbors) and v not in colors
        forbidden = {colors[q] for q in neighbors[v] if q in colors}
        allowed = [c for c in range(used) if c not in forbidden and loads[c] < capacity]
        if used < slots:
            allowed.append(used)
        children = node["children"]
        assert [x["color"] for x in children] == allowed
        for child in children:
            c = child["color"]
            colors[v] = c
            loads[c] += 1
            assert len(colors) < len(neighbors), "An exhausted proof contains a valid complete coloring"
            visit(child["proof"], max(used, c + 1))
            loads[c] -= 1
            del colors[v]
    visit(proof, 0)
    return nodes


def verify_certificate(state, order, certificate):
    pts = point_lines(state)
    center = certificate["center"]
    slots = order + 1 - len(pts[center])
    assert slots >= 0
    vertices = certificate["vertices"]
    assert len(set(vertices)) == len(vertices)
    assert all(v in pts and not pts[v] & pts[center] for v in vertices)
    kind = certificate["kind"]
    if kind == "clique":
        assert len(vertices) > slots
        assert all(pts[a] & pts[b] for a, b in combinations(vertices, 2))
        return {"kind": kind, "slots": slots, "required_distinct_lines": len(vertices)}
    if kind == "capacity":
        assert len(vertices) > slots * order
        return {"kind": kind, "slots": slots, "unjoined_points": len(vertices)}
    assert kind == "coloring_exhaustion"
    assert set(vertices) == {q for q in pts if not pts[q] & pts[center]}
    neighbors = [{j for j, b in enumerate(vertices) if i != j and pts[a] & pts[b]}
                 for i, a in enumerate(vertices)]
    count = verify_exhaustion(neighbors, slots, order, certificate["proof"])
    return {"kind": kind, "slots": slots, "proof_nodes": count}
