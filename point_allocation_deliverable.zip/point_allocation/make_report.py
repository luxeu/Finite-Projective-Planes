#!/usr/bin/env python3
"""Generate the explanatory report from the saved computation."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"


def main():
    summary = json.loads((OUT / "summary.json").read_text())
    audit = json.loads((OUT / "audit_summary.json").read_text())
    witness = json.loads((OUT / "target_witness.json").read_text())
    trace_rows = []
    for step in witness["trace"]:
        trace_rows.append(f'| l{12 + step["step"]} | '+', '.join(step["selected_points"])
                          +f' | {step["points"]} | {step["rho"]} |')
    edge_rows = ['| '+', '.join(edge['points'])+' | '+edge['existing_line']+' |'
                 for edge in witness['pair_line_witnesses']]
    cohort_labels = {'targeted': 'Targeted branch, including seed',
                     'first_layer': 'All first-layer symmetry representatives',
                     'hall9': 'Known Hall(9) completion states',
                     'general': 'Deeper baseline-generated sample'}
    status_rows, time_rows = [], []
    for name, cohort in summary['benchmark'].items():
        statuses = cohort['statuses']
        status_rows.append(f'| {cohort_labels[name]} | {cohort["states"]} | '
                           +str(statuses.get('passes_local_test', 0))+' | '
                           +str(statuses.get('rejected', 0))+' | '+str(statuses.get('unknown', 0))+' |')
        time_rows.append(f'| {cohort_labels[name]} | {cohort["baseline_seconds"]:.3f} | '
                         +f'{cohort["allocation_seconds"]:.3f} |')
    text = r'''# Point-allocation check: a certified rejection from configuration #1

**The proposed test now has a verified example where it adds a rejection.** Starting from Nation and Seffrood's configuration #1, six valid one-line extensions produce a semiplane with 18 lines and 71 points. It passes every previously checked numerical condition, but cannot be completed to order 12: five points need different new lines through `p7`, and only four such lines are available.

The example was constructed to expose the rule. A separate finite sample of 384 deeper states produced no additional rejection within the declared computation limits; 38 remained unresolved. The work establishes a sound additional obstruction, not a typical-search speedup or a result eliminating starting configuration #1. No claim of literature novelty is made.

## 1. Exact rule and proof

Let $S$ be a semiplane and let $n$ be the target order. For a current point $p$, write $d(p)$ for its current number of incident lines. Define

$$r=n+1-d(p).$$

These are the remaining lines through $p$ available in a putative completion. Let $U_p$ consist of the current points not already joined to $p$ by a current line.

Build a graph $H_p$ with vertex set $U_p$. Two vertices are adjacent when those two points already share a current line. A necessary condition for completion is:

> The vertices of $H_p$ can be assigned to at most $r$ colors so adjacent vertices have different colors, with at most $n$ vertices in each color.

**Proof.** In a completion, each point $q$ in $U_p$ lies on its unique joining line with $p$. That line is one of the $r$ lines through $p$ absent from the current semiplane. Give $q$ the color of that future line. If two adjacent vertices received the same color, their existing joining line and that future line through $p$ would both join the same two points, violating uniqueness. Each future line has $n+1$ points in total; after counting $p$, it can accommodate at most $n$ of these vertices. This supplies the required coloring whenever a completion exists.

Thus a certified failure of this coloring condition rejects the branch. A coloring that succeeds is only a local consistency result; it does not construct or guarantee a plane completion.

A particularly simple rejection certificate is a clique of more than $r$ vertices: all its points pairwise conflict, so they require more than $r$ different lines. A capacity certificate is also possible when $|U_p|>nr$.

## 2. Explicit construction from the original seed

Start with the previously reconstructed 12-line, 37-point configuration #1. The symbols `p1` through `p10` are the paper's points. A seed point `qi_j` is the distinct extra intersection of old lines `li` and `lj`.

The following table gives all the existing points selected for each new line. At every step, introduce a distinct fresh intersection with each old line not already met at a selected point, exactly as in the first deliverable.

| Added line | Selected existing points | Total points afterward | $\rho_{12}$ afterward |
| --- | --- | ---: | ---: |
@@TRACE@@

Every selection is structurally admissible. Every intermediate semiplane satisfies the original numerical checks, and the independent audit verifies that all six steps are genuine extensions retaining the full starting configuration.

At the end, `p7` lies on exactly nine lines:

$$l1,l2,l3,l13,l14,l15,l16,l17,l18.$$

An order-12 completion permits 13 lines through it, so **only four further lines through `p7` remain**.

## 3. The five-point obstruction

Exactly these five current points still lack a current joining line with `p7`:

$$p8,\quad p9,\quad p10,\quad q4\_12,\quad q7\_12.$$

Every pair already shares a current line:

| Pair of points | Existing joining line |
| --- | --- |
@@EDGES@@

Consequently no two of these points can lie on the same new line through `p7`. They require **five distinct additional lines** through it. Only **four** are available. That is the complete contradiction.

In graph language, $H_{p7}$ is $K_5$ and would need at least five colors, while $r=13-9=4$.

`results/target_witness.json` supplies the entire final incidence structure, the six extension steps, the five vertices and the ten pairwise joining-line witnesses. The independent checker verifies the contradiction directly from incidences, without importing the allocation solver.

## 4. Why the previous checks allow this branch

| Quantity | Value in the 18-line descendant | Existing necessary restriction |
| --- | ---: | --- |
| Represented points | 71 | At most 157 |
| Lines | 18 | At most 157 |
| Maximum lines through a point | 9 | At most 13 |
| Maximum represented points on a line | 13 | At most 13 |
| Point budget $\rho_{12}$ | 23 | Nonnegative |

There are 171 incidences, so

$$\rho_{12}=171+157-71-13(18)=23.$$

This proves that the point-allocation condition can detect a contradiction missed by this collection of numerical checks. It does not establish that the condition is new to the literature.

## 5. Implementation and certificates

For each current point, the implementation constructs the graph above. It first attempts a direct greedy coloring. If that fails, it searches for a clique certificate and then performs a bounded exact coloring search, including the capacity limit of $n$ vertices per color.

The clique search and exact coloring search each have a separate limit of **3,000 search nodes per point**. Failed greedy coloring alone never rejects a state. A completed exact search may reject it only after covering every permissible color assignment, with interchangeable unused colors represented once. Such a rejection includes the full branching proof for independent checking.

There are three whole-state outcomes:

| Status | Meaning |
| --- | --- |
| `passes_local_test` | Every point graph has a checked coloring satisfying the local requirements |
| `rejected` | At least one point has a complete, independently checkable impossibility certificate |
| `unknown` | No rejection certificate was found and at least one point search reached its limit |

Unknown states are never pruned. Passing this local test also never asserts that a plane completion exists.

## 6. Validation and fixed benchmark

### Solver validation

The exact coloring code was compared with direct enumeration on **3,921 small graph/capacity cases**. Its **2,232 uncolorability proofs** were independently checked. A five-cycle with two available colors exercises a rejection that has no three-vertex clique. A forced low node limit was checked to produce `unknown`.

### Known-plane control

The original seed embedding and all 79 missing Hall(9) lines give **80 known-completable states**. From the full plane's incidence data, we explicitly supplied and checked the actual future-line allocations for **6,796 point graphs**, including the capacity limits. This confirms the local rule against real completions.

The generic solver was then run on those same states without using the supplied future-line assignments. It rejected none, resolved 67, and returned `unknown` on 13 under its fixed search bounds. Those 13 are known-completable controls whose colorings the bounded generic search did not finish finding; they are not failures of the mathematical rule.

### General sample

Using random seed `2026111002`, choose 32 of the 548 first-layer representatives. From each, add 12 further lines. Each proposal uses a shuffled greedy compatible set of current points; only the original numerical checks determine whether it enters the corpus. The allocation test has no influence on corpus generation.

This produced **384 retained states**, reaching up to **25 total lines**. There were 485 proposals; 101 failed the numerical checks. The proposal budget was 128 per stage, and none of these 32 paths exhausted it. This is a correlated, finite heuristic sample, not uniform sampling of extensions or exhaustive deeper coverage.

### Outcomes

All states in this table pass the original numerical checks. The column marked unknown is distinct from a successful local allocation.

| Cohort | States | Passed local test | Rejected additionally | Unknown |
| --- | ---: | ---: | ---: | ---: |
@@STATUSES@@

All 548 first-layer representatives pass the local test. Their symmetry equivalences therefore also give local feasibility for all 5,528 labeled first-line extensions.

For the deliberately targeted branch, the seed and first five additions pass the local test. The sixth added line creates the certified rejection. **This does not claim that six is the earliest possible rejection depth over all descendants of the seed.**

Observed checking time on the original runtime was:

| Cohort | Original checks, seconds | Allocation check, seconds |
| --- | ---: | ---: |
@@TIMES@@

These times measure the additional checking work on fixed states. They do not measure an end-to-end exhaustive search. The full graph-coloring check is substantially more expensive than the numerical checks here. The general sample yielded zero certified extra rejections and 38 unknowns, so **these data do not establish a practical search speedup**.

## 7. Reduced obstruction

Retaining the nine lines through `p7` and the five lines used to join pairs in the certificate gives a **14-line, 51-point core**. Its maximum point degree is 9, maximum line size is 13, and $\rho_{12}=35$. It remains structurally valid, passes all numerical checks, and has the same five-point obstruction.

Deleting any one of these 14 lines destroys this particular certificate; all 14 deletions were checked. This is deletion minimality for the fixed certificate, not a claim that it is the smallest possible obstruction.

The reduced core no longer contains the full 12-line starting seed. The 18-line witness, with its verified six-step construction, is the object establishing an impossible descendant of configuration #1. `results/reduced_core.json` records the smaller core and its retained original line labels.

## 8. Independent audit and conclusion

The independent audit checks **@@AUDIT_STATES@@ stored state records**, including the core, all first-layer representatives and every retained general-sample state. These are records across the named cohorts, which can share states; they are not a count of distinct isomorphism classes. The audit verifies both rejection certificates, all target/general extension steps, and the 80 Hall-plane states against the full known plane. It does not import the allocation solver.

The authorized next deliverable is complete: the rule has been proved, implemented, validated and benchmarked, and an additional rejection has an explicit checked certificate.

The useful next implementation choice is to retain cheap clique obstructions while gathering evidence on when a full coloring search is worthwhile. The current benchmark does not justify invoking the full bounded coloring search at every search node. Starting configuration #1 itself remains unresolved.

## Reproduction and sources

Run `python3 experiment.py`, then `python3 audit_results.py`, then `python3 make_report.py` with Python 3.10 or later, without `-O`. No third-party packages or network access are needed. Deterministic states and counts are reproduced; timings vary.

- Starting incidences and extension framework: Nation and Seffrood, *Dual linear spaces generated by a non-Desarguesian configuration* (2011), [author-hosted PDF](https://math.hawaii.edu/~jb/planes-cdm.pdf), Table 2, Sections 3-4 and Appendix class 1.
- Known-plane incidence data: G. Eric Moorhouse, [Hall(9) data](https://ericmoorhouse.org/pub/planes/hall9.txt).
- The seed code, first-layer representatives and known completion trace were reused from the first deliverable. The current rule formulation, construction, software and measurements are presented as this project's checked work, without a literature-novelty claim.
'''
    text = (text.replace('@@TRACE@@', '\n'.join(trace_rows))
            .replace('@@EDGES@@', '\n'.join(edge_rows))
            .replace('@@STATUSES@@', '\n'.join(status_rows))
            .replace('@@TIMES@@', '\n'.join(time_rows))
            .replace('@@AUDIT_STATES@@', f'{audit["states_independently_validated"]:,}'))
    path = ROOT / 'POINT_ALLOCATION_REPORT.md'
    path.write_text(text)
    print(f'Wrote {path.name}: {len(text.split()):,} words')


if __name__ == '__main__':
    main()
