#!/usr/bin/env python3
"""Audit saved results with sets of points on lines, without importing census code."""
import csv
import hashlib
import json
from collections import Counter
from itertools import combinations
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"


def main():
    seed = json.loads((OUT / "seed1.json").read_text())
    point_lines = {row["point"]: set(row["lines"]) for row in seed["points"]}
    old_lines = {name: {p for p, row in point_lines.items() if name in row}
                 for name in seed["line_labels"]}
    assert len(point_lines) == 37 and len(old_lines) == 12
    assert sorted(map(len, old_lines.values())) == [7] * 9 + [8] * 3
    assert all(len(a & b) == 1 for a, b in combinations(old_lines.values(), 2))

    rows = list(csv.DictReader((OUT / "first_extensions.csv").open()))
    summary = json.loads((OUT / "summary.json").read_text())
    seen = set()
    histogram = Counter()
    orbit_counts = Counter()
    for row in rows:
        chosen = frozenset(row["selected_points"].split())
        assert chosen not in seen
        seen.add(chosen)
        assert chosen <= point_lines.keys()
        assert all(not (point_lines[a] & point_lines[b]) for a, b in combinations(chosen, 2))
        lines = {name: set(pts) for name, pts in old_lines.items()}
        new_line = set(chosen)
        uncovered = set()
        for name in old_lines:
            assert len(lines[name] & chosen) <= 1
            if not (lines[name] & chosen):
                uncovered.add(name)
                fresh = "fresh_on_" + name
                lines[name].add(fresh)
                new_line.add(fresh)
        lines["l13"] = new_line
        assert all(len(a & b) == 1 for a, b in combinations(lines.values(), 2))
        degrees = Counter(p for pts in lines.values() for p in pts)
        incidence_count = sum(map(len, lines.values()))
        rho = incidence_count + 157 - len(degrees) - 13 * 13
        reasons = []
        if len(degrees) > 157:
            reasons.append("point_count_exceeds_N")
        if len(lines) > 157:
            reasons.append("line_count_exceeds_N")
        if max(degrees.values()) > 13:
            reasons.append("point_degree_exceeds_n_plus_1")
        if max(map(len, lines.values())) > 13:
            reasons.append("line_size_exceeds_n_plus_1")
        if rho < 0:
            reasons.append("negative_rho")
        expected = {"selected_count": len(chosen), "new_points": len(uncovered),
                    "new_line_size": len(new_line), "total_points": len(degrees),
                    "total_lines": len(lines), "incidences": incidence_count,
                    "max_point_degree": max(degrees.values()),
                    "max_line_size": max(map(len, lines.values())), "rho12": rho}
        assert all(int(row[k]) == value for k, value in expected.items())
        assert set(row["uncovered_old_lines"].split()) == uncovered
        assert row["status"] == ("rejected" if reasons else "passes_necessary_checks")
        assert row["rejection_reasons"] == ";".join(reasons)
        histogram[len(chosen)] += 1
        orbit_counts[row["orbit_id"]] += 1
    assert len(rows) == summary["total_labeled_extensions"]
    assert dict(sorted(histogram.items())) == {int(k): v for k, v in summary["by_selected_existing_points"].items()}
    # A separate set-based include/exclude count also checks census completeness.
    states = {(frozenset(), 0): 1}
    for row in point_lines.values():
        following = Counter(states)
        for (used, size), count in states.items():
            if not (used & row):
                following[used | frozenset(row), size + 1] += count
        states = following
    dp_histogram = Counter()
    for (_, size), count in states.items():
        dp_histogram[size] += count
    assert dp_histogram == histogram
    orbits = list(csv.DictReader((OUT / "symmetry_orbits.csv").open()))
    assert len(orbits) == summary["seed_preserving_orbits"]
    for row in orbits:
        assert orbit_counts[row["orbit_id"]] == int(row["orbit_size"])
        assert frozenset(row["representative_points"].split()) in seen

    hall_bytes = (ROOT / "data" / "hall9.txt").read_bytes()
    hall_point_lines = [set(map(int, row.split())) for row in hall_bytes.splitlines()]
    hall_lines = {line: {p for p, row in enumerate(hall_point_lines) if line in row}
                  for line in range(91)}
    assert all(len(x) == 10 for x in hall_point_lines)
    assert all(len(x) == 10 for x in hall_lines.values())
    assert all(len(a & b) == 1 for a, b in combinations(hall_lines.values(), 2))
    assert all(len(a & b) == 1 for a, b in combinations(hall_point_lines, 2))
    control = json.loads((OUT / "hall9_validation.json").read_text())
    assert hashlib.sha256(hall_bytes).hexdigest() == control["data_sha256"]
    label_to_hall = dict(control["seed_point_embedding"])
    selected_lines = [control["seed_line_embedding"][name] for name in seed["line_labels"]]
    for name, row in point_lines.items():
        assert {seed["line_labels"][i] for i, line in enumerate(selected_lines)
                if label_to_hall[name] in hall_lines[line]} == row
    assert len(set(label_to_hall.values())) == 37
    for step in control["steps"]:
        hall_line = step["hall_line"]
        assert hall_line not in selected_lines
        actual_chosen = {name for name, hp in label_to_hall.items() if hp in hall_lines[hall_line]}
        assert set(step["existing_points_selected"]) == actual_chosen
        current_hall_points = set(label_to_hall.values())
        new_count = 0
        for i, previous in enumerate(selected_lines):
            intersection, = hall_lines[previous] & hall_lines[hall_line]
            if intersection not in current_hall_points:
                label_to_hall[f"q{len(selected_lines) + 1}_{i + 1}"] = intersection
                new_count += 1
        selected_lines.append(hall_line)
        current_hall_points = set(label_to_hall.values())
        # Rebuild the entire subsemiplane directly from the Hall plane at each step.
        all_meets = {next(iter(hall_lines[a] & hall_lines[b]))
                     for a, b in combinations(selected_lines, 2)}
        assert current_hall_points == all_meets
        ranks = [len(hall_lines[line] & all_meets) for line in selected_lines]
        rho9 = sum(ranks) + 91 - len(all_meets) - 10 * len(selected_lines)
        assert step["new_points"] == new_count
        assert step["points"] == len(all_meets)
        assert step["lines"] == len(selected_lines)
        assert step["rho9"] == rho9 >= 0
        assert max(ranks) <= 10
    assert len(selected_lines) == len(set(selected_lines)) == 91
    assert len(set(label_to_hall.values())) == len(label_to_hall) == 91
    print("PASS: all 5,528 rows reconstructed independently; DP completeness agrees;")
    print("548 orbit records reconciled; Hall(9) axioms, seed embedding and all 79 steps verified.")


if __name__ == "__main__":
    main()
