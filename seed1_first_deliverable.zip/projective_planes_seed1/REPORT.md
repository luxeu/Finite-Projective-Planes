# Configuration #1: complete first-line extension census

**The first deliverable is complete. There are exactly 5,528 structurally admissible ways to add one line to the fixed labeled seed. All 5,528 pass the checked order-12 necessary conditions.** They form 548 orbits under the seed's 12 symmetries. Configuration #1 remains unresolved.

Here, an extension means the seed plus one distinguished new line and the intersection points required by that line. Fresh point names are immaterial. These are counts for one fixed labeled seed, not counts of order-12 planes.

## 1. Reconstructed starting configuration

Nation and Seffrood's Appendix class 1 is the configuration obtained by using their method IV for every undefined intersection in Table 1: give each such pair of lines its own new intersection point, without adding any extra concurrency. The ten original points and their incidences are specified by Table 2. This introduces 27 additional points, for a total of 37.

The notation `qi_j` means the extra intersection of lines `li` and `lj`. The complete line-to-point incidence table is:

| Line | Current points on the line | Count |
| --- | --- | ---: |
| l1 | p1, p4, p7, q1_6, q1_9, q1_10, q1_11, q1_12 | 8 |
| l2 | p2, p5, p7, q2_5, q2_8, q2_10, q2_11, q2_12 | 8 |
| l3 | p3, p6, p7, q3_4, q3_7, q3_10, q3_11, q3_12 | 8 |
| l4 | p1, p2, p9, q3_4, q4_8, q4_9, q4_12 | 7 |
| l5 | p1, p3, p10, q2_5, q5_7, q5_9, q5_10 | 7 |
| l6 | p2, p3, p8, q1_6, q6_7, q6_8, q6_11 | 7 |
| l7 | p4, p5, p9, q3_7, q5_7, q6_7, q7_12 | 7 |
| l8 | p4, p6, p10, q2_8, q4_8, q6_8, q8_10 | 7 |
| l9 | p5, p6, p8, q1_9, q4_9, q5_9, q9_11 | 7 |
| l10 | p8, p9, q1_10, q2_10, q3_10, q5_10, q8_10 | 7 |
| l11 | p9, p10, q1_11, q2_11, q3_11, q6_11, q9_11 | 7 |
| l12 | p8, p10, q1_12, q2_12, q3_12, q4_12, q7_12 | 7 |

Checks on this reconstructed seed:

- 12 lines; 37 points; 87 incidences.
- Every pair of distinct lines meets in exactly one point.
- Every point lies on at least two lines; no two points share two lines.
- Seven points have degree 3, three have degree 4, and 27 have degree 2.
- Three lines have 8 points and nine have 7 points.
- The non-Desarguesian configuration is retained: `p7` is the perspective center of triangles `(p1,p2,p3)` and `(p4,p5,p6)`; the corresponding side intersections are `p9`, `p10`, `p8`, and no current line contains all three. Their three pairwise joining lines are already present, so a completion cannot make those points collinear.

An order-12 plane would have 157 points and 157 lines, with 13 incidences on each point and each line. The point-budget expression is

$$\rho_{12}(S)=I(S)+157-|P(S)|-13|L(S)|.$$

For the seed this gives

$$\rho_{12}(S)=87+157-37-13(12)=51,$$

matching the paper. If a completion exists, this quantity is the number of its points lying on none of the currently selected lines. It is not a count of additional lines, and it is not simply the number of points still absent from the current incidence structure.

The full point-to-line table is also supplied in `results/seed1.json`.

## 2. What was enumerated and why it is complete

Let $M$ be the set of existing points that will lie on the new line $k$.

A necessary structural rule is that no two points in $M$ already share an old line. Otherwise the old line and $k$ would have two points in common. Equivalently, the sets of old lines incident with the selected points must be pairwise disjoint.

For each old line that contains no selected point, add a fresh intersection point on that line and $k$. Let $D$ be this set of uncovered old lines. Use a different fresh point for each line in $D$.

These choices give

$$|P'|=37+|D|,\qquad |L'|=13,\qquad |k|=|M|+|D|.$$

Every structurally admissible subset $M$ was generated, including the empty subset, singletons, and nonmaximal subsets. Each was generated once in increasing point-index order. The recursion skips an entire subtree as soon as a selected point would share an old line with another selected point.

This covers every one-line extension: any actual added line determines its set $M$ of old points uniquely; its intersection with every uncovered old line must be a new point. Those new intersections must be distinct, since two old lines already meet at a represented old point. Conversely, each enumerated $M$ constructs a valid dual linear space by this rule. This is the one-line extension construction of Section 4 of the paper.

The stored census contains 5,528 rows, one for every such choice. It does not list incompatible subsets as candidate extensions. For example, selecting both `p1` and `p2` is excluded because both already lie on `l4`; the implementation's guard against this error was checked.

For a concrete passing example, choose $M=\{p1,p6\}$. Their incident old lines are disjoint: `p1` lies on `l1,l4,l5`, while `p6` lies on `l3,l8,l9`. The six uncovered old lines are `l2,l6,l7,l10,l11,l12`. Add one fresh intersection on each of those lines. The new line then has two old points and six fresh points, giving 8 represented points; the semiplane has 43 points and 13 lines, with $\rho_{12}=46$. The ledger records this choice and its checks.

## 3. Exact counts

| Existing points selected for the new line, $|M|$ | Extensions |
| ---: | ---: |
| 0 | 1 |
| 1 | 37 |
| 2 | 393 |
| 3 | 1,557 |
| 4 | 2,356 |
| 5 | 1,104 |
| 6 | 80 |
| **Total** | **5,528** |

There are **5,490** choices with at least two existing points. The other 38 choices consist of the empty subset and the 37 singletons. Including all of them makes the scope of the first-layer census explicit.

The number of represented points on the new line is:

| Points on new line, $|k|$ | Extensions |
| ---: | ---: |
| 5 | 33 |
| 6 | 347 |
| 7 | 1,582 |
| 8 | 2,148 |
| 9 | 1,128 |
| 10 | 262 |
| 11 | 27 |
| 12 | 1 |
| **Total** | **5,528** |

These are current points in the partial structure. A completed order-12 line would ultimately contain 13 points.

The measured parameter ranges are:

| Quantity after the first extension | Minimum | Maximum |
| --- | ---: | ---: |
| Total represented points | 37 | 49 |
| Total lines | 13 | 13 |
| Points on the new line | 5 | 12 |
| Maximum degree of any point | 4 | 5 |
| Maximum size of any line | 8 | 12 |
| $\rho_{12}$ | 43 | 50 |

## 4. Rejections: zero, with a direct explanation

The following necessary conditions were applied to every structurally admissible extension:

| Rejection condition | Extensions rejected |
| --- | ---: |
| More than 157 represented points | 0 |
| More than 157 lines | 0 |
| More than 13 lines through a point | 0 |
| More than 13 points on a line | 0 |
| Negative $\rho_{12}$ | 0 |

This is explained by the construction, independently of the census total:

1. There are only 12 old lines, so at most 12 new intersection points are added. Thus the new structure has at most $37+12=49$ represented points.
2. Every old point's degree rises by at most one, so it is at most 5. Every new point has degree 2.
3. Every old line gains at most one point, so its size is at most 9.
4. The new line meets the 12 old lines. Combining some of these intersections at selected old points can only reduce its number of represented points, so $|k|\leq12$.
5. The incidence count changes by $|M|+2|D|$, and therefore

$$\rho_{12}(S')=51+|k|-13=38+|k|>0.$$

The computed minimum $|k|=5$ gives the sharper observed bound $\rho_{12}\geq43$.

**Consequently these checks cannot eliminate configuration #1 at its first extension.** Passing them does not prove that any particular branch can be completed. The first layer is simply too early for these conditions to provide a rejection.

Every row in `results/first_extensions.csv` has status `passes_necessary_checks` and an empty rejection-reason field. There are no rejected admissible extensions for which to produce a rejection certificate at this layer.

## 5. Symmetry accounting

The seed admits 12 symmetries: permute the three corresponding vertex positions in the two triangles in the same way (6 choices), and optionally exchange the two triangles (2 choices). The induced permutations of all 37 points were checked against their incidences.

These are the full seed automorphism group. To see the bound, the three 8-point lines are distinguished by their sizes and have common point `p7`. The six other degree-3 points form two triangles under the old lines joining pairs of them; the three 8-point lines supply the matching between the triangles. Any automorphism must preserve this structure, leaving at most the 6 vertex permutations and the optional triangle exchange. The remaining lines and intersection points are determined by these choices.

Grouping the 5,528 choices under this group gives **548 orbits**. If only choices with $|M|\geq2$ are retained, the corresponding count is **539 orbits**.

| Orbit size | Number of orbits | Labeled extensions |
| ---: | ---: | ---: |
| 1 | 3 | 3 |
| 2 | 8 | 16 |
| 3 | 17 | 51 |
| 4 | 1 | 4 |
| 6 | 129 | 774 |
| 12 | 390 | 4,680 |
| **Total** | **548** | **5,528** |

Orbit sizes were reconciled with the labeled census. As a separate consistency check, the sum of fixed-subset counts over the 12 group elements is 6,576; Burnside's formula gives $6,576/12=548$.

These orbits preserve the original seed and distinguish the newly added line. They are not a classification of unmarked 13-line structures, where an isomorphism might send the added line to one of the original lines.

## 6. Verification completed

**Every extension was checked.** The code validates all pairwise line intersections and all reported metrics, rather than checking only a sample.

**The total was counted by an independent method.** An include/exclude dynamic program, indexed by the subset of old lines already covered and the number of selected points, matches the recursive enumeration's entire joint histogram of $(|M|,|k|)$.

**A separate audit reconstructs every saved row using sets of points on lines.** `verify_results.py` does not import the enumeration module. It checks the census ledger, a separate set-based dynamic-programming count, the orbit records, and the known-plane validation.

**Positive control using a known non-Desarguesian plane.** G. Eric Moorhouse's Hall(9) incidence file was checked directly: 91 points, 91 lines, degree 10 on each point and line, and unique joins and intersections. A deterministic search found an embedding of the entire 37-point seed into that plane. The explicit point and line mapping is saved in `results/hall9_validation.json`.

The seed-line mapping to Moorhouse's zero-based Hall(9) line numbers is:

| Seed line | Hall(9) line |
| --- | ---: |
| l1 | 74 |
| l2 | 28 |
| l3 | 55 |
| l4 | 26 |
| l5 | 41 |
| l6 | 82 |
| l7 | 60 |
| l8 | 83 |
| l9 | 64 |
| l10 | 75 |
| l11 | 42 |
| l12 | 24 |

Starting from this embedding, the same extension code added all 79 missing Hall-plane lines. Every step passed incidence validation and the order-9 conditions. The result has 91 points, 91 lines, degree 10 throughout, and $\rho_9=0$. The separate audit also reconstructs every step directly from the Hall incidence data.

This is a positive control with a supplied known completion, not a blind search discovering a new plane. It validates that the extension machinery follows a real completion correctly.

## 7. Scope and next computation

This deliverable completes the promised reconstruction and exhaustive first-line census. It does not enumerate the second layer, implement the proposed conflict-graph test, or reject the starting configuration.

For a second-layer investigation, the 548 representatives are a smaller complete starting set under seed-preserving symmetry. A deeper search still needs complete branch coverage and justified rejection rules. Its feasibility must be measured; first-layer survival gives no evidence that a full order-12 plane exists.

## Sources

1. J. B. Nation and Jiajia Y. G. Seffrood, *Dual linear spaces generated by a non-Desarguesian configuration*, Contributions to Discrete Mathematics 6(1) (2011). [Journal record](https://cdm.ucalgary.ca/article/view/62078); [DOI](https://doi.org/10.55016/ojs/cdm.v6i1.62078); [author-hosted PDF used here](https://math.hawaii.edu/~jb/planes-cdm.pdf). Relevant portions: Table 2; Section 3 (point budget); Section 4 (one-line extensions); Appendix class 1.
2. G. Eric Moorhouse, [Projective Planes of Small Order](https://ericmoorhouse.org/pub/planes/), [Hall(9) incidence data](https://ericmoorhouse.org/pub/planes/hall9.txt). The delivered data file preserves the numerical rows with normalized whitespace.

The counts and explicit embedding in this report were computed for this deliverable; no claim of research novelty is made.
