import json
from pathlib import Path
from seed1 import build_seed,choices,Semiplane
ns={'__file__':str(Path(__file__).with_name('run.py'))}
exec(Path(ns['__file__']).read_text().split('\ncorpus=')[0],ns)
s=build_seed();pair,bad=ns['screen'](s);assert not bad
_,a,b=pair[0]
expected={chosen for chosen,covered in choices(s.supports) if a in chosen and b in chosen}
actual=set()
for child in ns['candidates'](s,pair):
    child.validate()
    actual.add(tuple(i for i in range(37) if child.supports[i]&(1<<12)))
assert expected==actual
checks=0
for entry in json.loads(Path(__file__).with_name('corpus.json').read_text()):
    if entry['cohort']=='hall9':
        w=entry['state'];state=Semiplane(tuple(w['labels']),tuple(w['supports']),w['line_count'])
        assert not ns['screen'](state,9)[1]
        checks+=1
print({'complete_seed_pair_extensions':len(actual),'known_plane_states_not_rejected':checks})
