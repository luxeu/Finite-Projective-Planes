import json,time
from pathlib import Path
from itertools import combinations
from collections import Counter
from seed1 import Semiplane,bits,rejection_reasons
from allocation import check_state
from certificate_check import verify_certificate
ROOT=Path(__file__).resolve().parent

def screen(s,order=12):
    compatible=[sum(1<<j for j,t in enumerate(s.supports) if not t&v) for v in s.supports]
    full=[]
    for l in range(s.line_count):
        pm=sum(1<<i for i,t in enumerate(s.supports) if t&(1<<l))
        if pm.bit_count()==order+1:full.append((l,pm))
    best=None
    for a in range(len(s.labels)):
        for b in bits(compatible[a]&~((1<<(a+1))-1)):
            if s.supports[a].bit_count()==order+1 or s.supports[b].bit_count()==order+1:return None,True
            allowed=compatible[a]&compatible[b]
            for l,pm in full:
                if not (s.supports[a]|s.supports[b])&(1<<l) and not pm&allowed:return None,True
            key=(allowed.bit_count(),a,b)
            if best is None or key<best[0]:best=(key,allowed)
    return best,False

def candidates(s,pair):
    (_,a,b),mask=pair
    options=list(bits(mask))
    def rec(i,covered,chosen):
        yield chosen
        for k in range(i,len(options)):
            p=options[k]
            if not covered&s.supports[p]:
                yield from rec(k+1,covered|s.supports[p],chosen+(p,))
    for selected in rec(0,s.supports[a]|s.supports[b],(a,b)):
        yield s.add_line(selected)[0]

def search(start,color):
    counts=Counter(); begin=time.perf_counter(); certificates=[]
    def visit(s,depth):
        if counts['nodes']>=10:return 'unknown'
        counts['nodes']+=1
        if rejection_reasons(s,12):counts['numerical_rejections']+=1;return 'rejected'
        pair,bad=screen(s)
        if bad:counts['join_rejections']+=1;return 'rejected'
        if color:
            result=check_state(s,12,node_limit=3000,clique_node_limit=3000)
            counts['color_'+result['status']]+=1
            if result['status']=='rejected':
                raw={'labels':s.labels,'supports':s.supports,'line_count':s.line_count}
                verify_certificate(raw,12,result['certificate'])
                certificates.append({'state':raw,'certificate':result['certificate']})
                return 'rejected'
        if depth==0 or pair is None:return 'unknown'
        unresolved=False
        for child in candidates(s,pair):
            if counts['proposals']>=1000:return 'unknown'
            counts['proposals']+=1
            if rejection_reasons(child,12):counts['numerical_rejections']+=1;continue
            status=visit(child,depth-1)
            unresolved|=status=='unknown'
            if counts['nodes']>=10:return 'unknown'
        return 'unknown' if unresolved else 'rejected'
    status=visit(start,2)
    return {'status':status,'counts':dict(counts),'seconds':time.perf_counter()-begin,'certificates':certificates}

corpus=json.loads((ROOT/'corpus.json').read_text())
roots=[x for x in corpus if x['id']=='target_06']
roots += [x for x in corpus if x['cohort']=='general' and x['id'].endswith('_12')][:8]
results=[]
for entry in roots:
    raw=entry['state'];s=Semiplane(tuple(raw['labels']),tuple(raw['supports']),raw['line_count'])
    row={'id':entry['id'],'baseline':search(s,False),'with_coloring':search(s,True)}
    results.append(row)
    print(json.dumps({k:v for k,v in row.items()}),flush=True)
    (ROOT/'results.json').write_text(json.dumps({'limits':{'nodes_per_root':10,'proposals_per_root':1000,'added_line_depth':2},'results':results},indent=2))
