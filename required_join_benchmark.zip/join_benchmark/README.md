# Required-join search pilot

The stronger baseline and the version with coloring reached the same node and rejection counts in this bounded pilot. Coloring supplied no additional rejection.

The baseline applies the numerical conditions, rejects unjoined pairs with a saturated endpoint, and checks whether their required joining line can intersect every already full old line at a compatible existing point. It then selects an unjoined pair with the fewest compatible additional points and enumerates every compatible selection containing that pair. Every completion must contain its joining line; therefore this branching choice is complete for that requirement.

The baseline does not exhaustively test every possible joining line for every pair before branching. Its inexpensive screen checks the stated necessary conditions. The selected pair's alternatives are enumerated subject to the explicit computation bounds.

Both versions use identical deterministic pair selection and extension ordering. The augmented version applies the previous point-allocation test, with separate 3,000-node clique and coloring limits per point. An unknown coloring outcome never prunes.

## Fixed scope

Nine starting states: the deliberate 18-line witness and the first eight 25-line endpoints in the previously saved general corpus. Each search is limited to two further lines, ten visited nodes and 1,000 candidate proposals. The initial 100-node pilot was interrupted because of its coloring cost; the reported runs were restarted with the identical ten-node limit for both versions. These are small, correlated cases, not representative or exhaustive coverage.

Any surviving depth frontier, exhausted node/proposal budget, or unhandled closed subplane returns unknown. A complete traversal of all generated children can return rejected only if every child was rejected. Neither a cutoff nor a coloring timeout proves nonexistence.

| Root | Baseline result | Baseline nodes | Coloring nodes | Baseline seconds | Coloring seconds |
| --- | --- | ---: | ---: | ---: | ---: |
| target_06 | rejected | 1 | 1 | 0.0005 | 0.0006 |
| general_01_12 | unknown | 10 | 10 | 0.0256 | 6.1085 |
| general_02_12 | unknown | 10 | 10 | 0.0490 | 15.4913 |
| general_03_12 | unknown | 10 | 10 | 0.0346 | 9.4835 |
| general_04_12 | unknown | 10 | 10 | 0.0370 | 12.8852 |
| general_05_12 | unknown | 10 | 10 | 0.0266 | 11.3582 |
| general_06_12 | unknown | 10 | 10 | 0.0435 | 14.3911 |
| general_07_12 | unknown | 10 | 10 | 0.0298 | 10.7315 |
| general_08_12 | unknown | 10 | 10 | 0.0412 | 13.5518 |

## Aggregate results

```json
{
  "baseline": {
    "counts": {
      "nodes": 81,
      "join_rejections": 1,
      "proposals": 330,
      "numerical_rejections": 258
    },
    "seconds": 0.2877853899994989,
    "root_statuses": {
      "rejected": 1,
      "unknown": 8
    }
  },
  "with_coloring": {
    "counts": {
      "nodes": 81,
      "join_rejections": 1,
      "color_passes_local_test": 2,
      "proposals": 330,
      "numerical_rejections": 258,
      "color_unknown": 78
    },
    "seconds": 94.00174172600009,
    "root_statuses": {
      "rejected": 1,
      "unknown": 8
    }
  }
}
```

## Validation

The new joining-line enumerator exactly matched all four first-layer choices containing the selected pair, obtained independently by filtering the complete seed census. Every resulting structure was validated. The full-line screen rejected none of the 80 known Hall-plane states when run with order-9 limits. Any coloring rejection would be independently certificate-checked; none occurred in this pilot.

## Interpretation

The showcase branch is rejected by the baseline at its root. The eight general roots remain unresolved. This pilot supports omitting coloring from routine checking in this implementation; it does not prove the coloring condition is redundant or could never help a deeper search. No order-12 seed has been eliminated.

## Reproduce

Python 3.10+, standard library only. Run without -O:

```bash
python3 validate.py
python3 run.py
```

The scripts reuse the previously checked seed and allocation modules and saved corpus. `results.json` records limits, per-root counters, outcomes and timings. Timings vary between runs.
