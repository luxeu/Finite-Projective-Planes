"""Recommended inexpensive checks. Passing does NOT certify extendibility."""
from experiment import context, singles, children
from propagation import propagate, verify
from semiplane import rejection_reasons

def assess(s,order=12):
    reasons=rejection_reasons(s,order)
    if reasons:return {'status':'rejected','stage':'numerical','reasons':reasons}
    ctx=context(s,order);bad,pair=singles(s,ctx,order)
    if bad:return {'status':'rejected','stage':'single_full_line_or_saturated_point'}
    if pair is None:return {'status':'passes_checked_conditions','pair':None,'forced':None}
    result=propagate(s,pair,ctx,order)
    if result['rejected']:
        verify(s,result,order)
        return {'status':'rejected','stage':'forced_full_line_intersections','certificate':result}
    return {'status':'passes_checked_conditions','pair':pair,'forced':result['chosen']}

def extensions(s,order=12,stats=None,limit=20000,use_forced=True):
    result=assess(s,order)
    if result['status']=='rejected':return
    yield from children(s,result['pair'],n=order,stats=stats,limit=limit,
                        early=True,forced=result['forced'] if use_forced else None)
