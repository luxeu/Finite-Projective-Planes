#!/usr/bin/env python3
"""Exact first-line census for Nation--Seffrood class 1 (Python stdlib only).

Sources: https://math.hawaii.edu/~jb/planes-cdm.pdf (Tables 1--2,
Sections 3--4, Appendix class 1); Hall(9) incidence data by G. Eric Moorhouse,
https://ericmoorhouse.org/pub/planes/hall9.txt.

No numerical claim here establishes extendibility to order 12. A surviving
extension only passes the explicit necessary conditions checked below.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
from collections import Counter
from dataclasses import dataclass
from itertools import combinations, permutations
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = "https://math.hawaii.edu/~jb/planes-cdm.pdf"
BASE_POINT_LINES = (
    (1, 4, 5), (2, 4, 6), (3, 5, 6),
    (1, 7, 8), (2, 7, 9), (3, 8, 9),
    (1, 2, 3), (6, 9, 10, 12), (4, 7, 10, 11), (5, 8, 11, 12),
)


def bits(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


@dataclass(frozen=True)
class Semiplane:
    labels: tuple[str, ...]
    supports: tuple[int, ...]
    line_count: int

    def ranks(self):
        return tuple(sum(bool(s & (1 << j)) for s in self.supports)
                     for j in range(self.line_count))

    def rho(self, order):
        return (sum(s.bit_count() for s in self.supports)
                + order * order + order + 1 - len(self.supports)
                - self.line_count * (order + 1))

    def validate(self):
        assert len(self.labels) == len(self.supports)
        assert len(set(self.labels)) == len(self.labels)
        pair_count = Counter()
        for support in self.supports:
            assert support.bit_count() >= 2
            assert support >> self.line_count == 0
            pair_count.update(combinations(bits(support), 2))
        assert pair_count == Counter({pair: 1 for pair in
                                      combinations(range(self.line_count), 2)})
        # Together these checks say that each pair of lines has precisely one
        # common point; consequently no two points share two different lines.

    def add_line(self, chosen):
        chosen = tuple(chosen)
        assert len(chosen) == len(set(chosen))
        covered = 0
        for p in chosen:
            if self.supports[p] & covered:
                raise ValueError("two selected points already share an old line")
            covered |= self.supports[p]
        new_bit = 1 << self.line_count
        selected = set(chosen)
        labels = list(self.labels)
        supports = [s | new_bit if p in selected else s
                    for p, s in enumerate(self.supports)]
        uncovered = tuple(bits(((1 << self.line_count) - 1) ^ covered))
        for old_line in uncovered:
            labels.append(f"q{self.line_count + 1}_{old_line + 1}")
            supports.append(new_bit | (1 << old_line))
        return Semiplane(tuple(labels), tuple(supports), self.line_count + 1), uncovered


def build_seed():
    labels = [f"p{i + 1}" for i in range(10)]
    supports = [sum(1 << (j - 1) for j in lines) for lines in BASE_POINT_LINES]
    for a, b in combinations(range(12), 2):
        pair = (1 << a) | (1 << b)
        if not any(s & pair == pair for s in supports):
            labels.append(f"q{a + 1}_{b + 1}")
            supports.append(pair)
    seed = Semiplane(tuple(labels), tuple(supports), 12)
    seed.validate()
    assert len(seed.labels) == 37
    assert sum(s.bit_count() for s in seed.supports) == 87
    assert seed.ranks() == (8, 8, 8, 7, 7, 7, 7, 7, 7, 7, 7, 7)
    assert seed.rho(12) == 51
    return seed


def choices(supports):
    """Every pairwise-compatible subset exactly once, including empty/singleton."""
    def visit(start, covered, chosen):
        yield chosen, covered
        for p in range(start, len(supports)):
            if not covered & supports[p]:
                yield from visit(p + 1, covered | supports[p], chosen + (p,))
    return visit(0, 0, ())


def independent_dp(supports, line_count):
    """Independent include/exclude DP; no use of the recursive enumerator."""
    states = {(0, 0): 1}
    for support in supports:
        increments = Counter()
        for (covered, size), count in states.items():
            if not covered & support:
                increments[covered | support, size + 1] += count
        for state, count in increments.items():
            states[state] = states.get(state, 0) + count
    histogram = Counter()
    for (covered, size), count in states.items():
        histogram[size, size + line_count - covered.bit_count()] += count
    return histogram


def rejection_reasons(semiplane, order):
    maximum = order * order + order + 1
    reasons = []
    if len(semiplane.labels) > maximum:
        reasons.append("point_count_exceeds_N")
    if semiplane.line_count > maximum:
        reasons.append("line_count_exceeds_N")
    if any(s.bit_count() > order + 1 for s in semiplane.supports):
        reasons.append("point_degree_exceeds_n_plus_1")
    if any(r > order + 1 for r in semiplane.ranks()):
        reasons.append("line_size_exceeds_n_plus_1")
    if semiplane.rho(order) < 0:
        reasons.append("negative_rho")
    return reasons


def seed_symmetries(seed):
    """The 12 relabelings from permuting vertices and swapping the triangles."""
    original_line_points = [frozenset(p for p, s in enumerate(seed.supports[:10])
                                      if s & (1 << j)) for j in range(12)]
    line_by_original_points = {s: j for j, s in enumerate(original_line_points)}
    point_by_support = {s: p for p, s in enumerate(seed.supports)}
    opposite_side = {frozenset((1, 2)): 7, frozenset((0, 1)): 8,
                     frozenset((0, 2)): 9}
    result = []
    for vertex_map in permutations(range(3)):
        for swap in range(2):
            point_map = {p: ((p // 3) ^ swap) * 3 + vertex_map[p % 3]
                         for p in range(6)}
            point_map[6] = 6
            for side, p in opposite_side.items():
                point_map[p] = opposite_side[frozenset(vertex_map[v] for v in side)]
            line_map = [line_by_original_points[frozenset(point_map[p] for p in s)]
                        for s in original_line_points]
            permutation = tuple(point_by_support[sum(1 << line_map[j] for j in bits(s))]
                                for s in seed.supports)
            assert len(set(permutation)) == len(seed.labels)
            result.append(permutation)
    assert len(set(result)) == 12
    return result


def image_of(chosen, permutation):
    return sum(1 << permutation[p] for p in chosen)


def hall_control(seed, hall_path):
    """Find a seed embedding, then replay all 79 missing Hall(9) lines."""
    raw = hall_path.read_bytes()
    point_lines = tuple(tuple(map(int, row.split())) for row in raw.splitlines() if row.strip())
    assert len(point_lines) == 91
    assert all(len(row) == len(set(row)) == 10 for row in point_lines)
    assert set(x for row in point_lines for x in row) == set(range(91))
    line_points = [set() for _ in range(91)]
    for p, row in enumerate(point_lines):
        for line in row:
            line_points[line].add(p)
    assert all(len(row) == 10 for row in line_points)
    joins, meets = {}, {}
    for p, row in enumerate(point_lines):
        for pair in combinations(sorted(row), 2):
            assert pair not in meets
            meets[pair] = p
    for line, row in enumerate(line_points):
        for pair in combinations(sorted(row), 2):
            assert pair not in joins
            joins[pair] = line
    assert len(joins) == len(meets) == 4095
    def join(a, b):
        return joins[tuple(sorted((a, b)))]
    def meet(a, b):
        return meets[tuple(sorted((a, b)))]
    rng = random.Random(20261109)
    target_supports = set(seed.supports)
    for trial in range(1, 200001):
        center = rng.randrange(91)
        pencils = rng.sample(sorted(point_lines[center]), 3)
        pairs = [rng.sample(sorted(line_points[line] - {center}), 2) for line in pencils]
        a, b, c = [pair[0] for pair in pairs]
        aa, bb, cc = [pair[1] for pair in pairs]
        lines = pencils + [join(a, b), join(a, c), join(b, c),
                           join(aa, bb), join(aa, cc), join(bb, cc)]
        if len(set(lines)) != 9:
            continue
        p8, p9, p10 = meet(lines[5], lines[8]), meet(lines[3], lines[6]), meet(lines[4], lines[7])
        if len({p8, p9, p10}) != 3:
            continue
        lines += [join(p8, p9), join(p9, p10), join(p8, p10)]
        if len(set(lines)) != 12:
            continue
        supports_by_hall_point = {}
        for i, j in combinations(range(12), 2):
            p = meet(lines[i], lines[j])
            supports_by_hall_point[p] = supports_by_hall_point.get(p, 0) | (1 << i) | (1 << j)
        if set(supports_by_hall_point.values()) == target_supports:
            break
    else:
        raise AssertionError("positive-control embedding not found within deterministic trial limit")
    hall_by_support = {s: p for p, s in supports_by_hall_point.items()}
    local_to_hall_point = [hall_by_support[s] for s in seed.supports]
    initial_point_map = dict(zip(seed.labels, local_to_hall_point))
    initial_line_map = {f"l{i + 1}": x for i, x in enumerate(lines)}
    current = seed
    trace = []
    for hall_line in sorted(set(range(91)) - set(lines)):
        chosen = tuple(p for p, hp in enumerate(local_to_hall_point)
                       if hall_line in point_lines[hp])
        following, uncovered = current.add_line(chosen)
        local_to_hall_point.extend(meet(lines[j], hall_line) for j in uncovered)
        assert len(set(local_to_hall_point)) == len(local_to_hall_point)
        lines.append(hall_line)
        following.validate()
        assert rejection_reasons(following, 9) == []
        for p, support in enumerate(following.supports):
            expected = sum(1 << j for j, hl in enumerate(lines)
                           if hl in point_lines[local_to_hall_point[p]])
            assert support == expected
        trace.append({"step": len(trace) + 1, "hall_line": hall_line,
                      "existing_points_selected": [current.labels[p] for p in chosen],
                      "new_points": len(uncovered), "points": len(following.labels),
                      "lines": following.line_count, "rho9": following.rho(9)})
        current = following
    assert len(current.labels) == current.line_count == 91
    assert set(current.ranks()) == {10}
    assert {s.bit_count() for s in current.supports} == {10}
    assert current.rho(9) == 0
    return {"source": "https://ericmoorhouse.org/pub/planes/hall9.txt",
            "data_sha256": hashlib.sha256(raw).hexdigest(), "random_seed": 20261109,
            "trials_to_embedding": trial, "seed_point_embedding": initial_point_map,
            "seed_line_embedding": initial_line_map, "steps": trace,
            "final_points": 91, "final_lines": 91, "final_rho9": 0,
            "all_79_steps_passed_incidence_and_order9_checks": True}


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def run(output):
    output.mkdir(parents=True, exist_ok=True)
    seed = build_seed()
    syms = seed_symmetries(seed)
    write_json(output / "seed1.json", {
        "source": SOURCE, "class": 1, "line_labels": [f"l{i + 1}" for i in range(12)],
        "points": [{"point": name, "lines": [f"l{j + 1}" for j in bits(s)]}
                   for name, s in zip(seed.labels, seed.supports)],
        "point_count": 37, "line_count": 12, "incidences": 87, "rho12": 51})
    histogram = Counter()
    by_size = Counter()
    by_rank = Counter()
    failures = Counter()
    rejected_count = 0
    orbits = {}
    fixed_counts = [0] * 12
    ranges = {key: [] for key in ("points", "new_line_size", "max_point_degree", "max_line_size", "rho12")}
    fields = ["extension_id", "selected_count", "selected_points", "uncovered_old_lines",
              "new_points", "new_line_size", "total_points", "total_lines", "incidences",
              "max_point_degree", "max_line_size", "rho12", "status", "rejection_reasons", "orbit_id"]
    with (output / "first_extensions.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for number, (chosen, covered) in enumerate(choices(seed.supports), 1):
            extended, uncovered = seed.add_line(chosen)
            extended.validate()  # Every row, not just a sample.
            size = len(chosen)
            rank = size + len(uncovered)
            assert rank == 12 - sum(seed.supports[p].bit_count() - 1 for p in chosen)
            assert extended.rho(12) == 51 + rank - 13
            reasons = rejection_reasons(extended, 12)
            rejected_count += bool(reasons)
            failures.update(reasons)
            histogram[size, rank] += 1
            by_size[size] += 1
            by_rank[rank] += 1
            images = [image_of(chosen, perm) for perm in syms]
            selection_mask = sum(1 << p for p in chosen)
            for i, im in enumerate(images):
                fixed_counts[i] += (im == selection_mask)
            canonical = min(images)
            if canonical not in orbits:
                orbits[canonical] = {"orbit_id": f"O{len(orbits) + 1:04d}", "count": 0,
                                     "representative": canonical, "orbit_size": len(set(images)),
                                     "selected_count": size}
            orbit = orbits[canonical]
            orbit["count"] += 1
            ranks = extended.ranks()
            metrics = {"points": len(extended.labels), "new_line_size": rank,
                       "max_point_degree": max(s.bit_count() for s in extended.supports),
                       "max_line_size": max(ranks), "rho12": extended.rho(12)}
            for key, value in metrics.items():
                ranges[key].append(value)
            writer.writerow({"extension_id": f"E{number:05d}", "selected_count": size,
                             "selected_points": " ".join(seed.labels[p] for p in chosen),
                             "uncovered_old_lines": " ".join(f"l{j + 1}" for j in uncovered),
                             "new_points": len(uncovered), "new_line_size": rank,
                             "total_points": len(extended.labels), "total_lines": 13,
                             "incidences": sum(s.bit_count() for s in extended.supports),
                             "max_point_degree": metrics["max_point_degree"],
                             "max_line_size": metrics["max_line_size"], "rho12": extended.rho(12),
                             "status": "rejected" if reasons else "passes_necessary_checks",
                             "rejection_reasons": ";".join(reasons), "orbit_id": orbit["orbit_id"]})
    dp = independent_dp(seed.supports, 12)
    assert dp == histogram
    total = sum(histogram.values())
    assert sum(fixed_counts) == 12 * len(orbits)  # Burnside's identity.
    assert all(x["count"] == x["orbit_size"] for x in orbits.values())
    with (output / "symmetry_orbits.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["orbit_id", "orbit_size", "representative_points", "selected_count"])
        writer.writeheader()
        for orbit in orbits.values():
            writer.writerow({"orbit_id": orbit["orbit_id"], "orbit_size": orbit["orbit_size"],
                             "representative_points": " ".join(seed.labels[p] for p in bits(orbit["representative"])),
                             "selected_count": orbit["selected_count"]})
    control = hall_control(seed, ROOT / "data" / "hall9.txt")
    write_json(output / "hall9_validation.json", control)
    # Ensure the structural guard actually rejects a conflicting pair.
    try:
        seed.add_line((0, 1))  # p1 and p2 already lie on l4.
    except ValueError:
        structural_guard = True
    else:
        raise AssertionError("invalid extension accepted")
    summary = {"source": SOURCE, "order": 12, "seed": {"class": 1, "points": 37,
               "lines": 12, "incidences": 87, "rho12": 51},
               "scope": "All one-line extensions of the fixed labeled seed; new line distinguished; empty and singleton selections included.",
               "total_labeled_extensions": total, "with_at_least_two_existing_points": total - by_size[0] - by_size[1],
               "rejected_by_checked_order12_conditions": rejected_count,
               "rejection_reason_counts": {r: failures[r] for r in
                 ["point_count_exceeds_N", "line_count_exceeds_N", "point_degree_exceeds_n_plus_1",
                  "line_size_exceeds_n_plus_1", "negative_rho"]},
               "by_selected_existing_points": dict(sorted(by_size.items())),
               "by_new_line_size": dict(sorted(by_rank.items())),
               "joint_histogram": [{"selected_count": k, "new_line_size": r, "count": c}
                                   for (k, r), c in sorted(histogram.items())],
               "ranges": {key: [min(values), max(values)] for key, values in ranges.items()},
               "seed_symmetry_group_size": 12, "seed_preserving_orbits": len(orbits),
               "seed_preserving_orbits_with_at_least_two_existing_points": sum(x["selected_count"] >= 2 for x in orbits.values()),
               "burnside_fixed_counts": fixed_counts,
               "verification": {"every_extension_incidence_checked": True,
                 "independent_dynamic_programming_count_agrees": True,
                 "orbit_sizes_and_burnside_identity_agree": True,
                 "invalid_pair_guard_checked": structural_guard,
                 "hall9_embedding_and_all_79_completion_steps_checked": True},
               "limitations": ["Passing necessary checks does not prove a completion exists.",
                 "Only one line beyond the seed was enumerated for order 12.",
                 "No conflict-graph rejection test is included in this first deliverable.",
                 "Orbits preserve the original seed and distinguish the added line; these are not unmarked 13-line isomorphism classes."]}
    write_json(output / "summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in ("joint_histogram", "limitations")}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    run(args.output)
