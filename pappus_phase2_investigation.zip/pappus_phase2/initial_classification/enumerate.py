"""Enumerate completions of the standard, nine-distinct-point Pappus failure.
Run with Python 3; install networkx and pynauty for classification.
Points are encoded by the sets of line indices incident with them.
"""
from itertools import combinations
from collections import Counter
from pathlib import Path
import json, time

def seed():
    names = ['A', 'B'] + [f'L{i}{j}' for i in range(3) for j in range(3) if i != j] + ['D01','D02','D12']
    ix = {n:i for i,n in enumerate(names)}
    points = []
    for i in range(3):
        points.append(frozenset([ix['A']] + [ix[f'L{i}{j}'] for j in range(3) if j != i]))
    for i in range(3):
        points.append(frozenset([ix['B']] + [ix[f'L{j}{i}'] for j in range(3) if j != i]))
    for i in range(3):
        j,k = [j for j in range(3) if j != i]
        points.append(frozenset([ix[f'L{j}{k}'],ix[f'L{k}{j}']] + [ix[f'D{a}{b}'] for a,b in combinations(range(3),2) if i in (a,b)]))
    return names, points

def pairs(s):
    return set(combinations(sorted(s),2))

def enumerate_completions():
    names, base = seed()
    fixed = set().union(*(pairs(p) for p in base))
    assert sum(len(pairs(p)) for p in base) == len(fixed) == 36
    # Every unprescribed old point/line incidence is forbidden by a double meet.
    for p in base:
        for l in set(range(11))-p:
            assert any(tuple(sorted((l,m))) in fixed for m in p)
    remaining = pairs(range(11))-fixed
    assert len(remaining)==19
    cliques = [frozenset(c) for k in range(2,12) for c in combinations(range(11),k) if pairs(c)<=remaining]
    cp = {c:pairs(c) for c in cliques}
    out=[]
    def rec(left, chosen):
        if not left:
            out.append(tuple(sorted(chosen,key=lambda c:tuple(sorted(c)))))
            return
        e=min(left)
        for c in cliques:
            if e in cp[c] and cp[c]<=left:
                rec(left-cp[c], chosen+[c])
    rec(remaining,[])
    # Independent enumeration: choose edge-disjoint cliques of size >=3;
    # all uncovered edges are then mandatory two-line points.
    big=[c for c in cliques if len(c)>=3]
    alt=set()
    def subsets(i,used,chosen):
        if i==len(big):
            ps=chosen+[frozenset(e) for e in remaining-used]
            alt.add(tuple(sorted(tuple(sorted(p)) for p in ps)))
            return
        subsets(i+1,used,chosen)
        c=big[i]
        if not (cp[c]&used): subsets(i+1,used|cp[c],chosen+[c])
    subsets(0,set(),[])
    assert alt=={tuple(tuple(sorted(p)) for p in ps) for ps in out}
    return names,base,remaining,cliques,out

def graph(points):
    import networkx as nx
    g=nx.Graph()
    g.add_nodes_from(range(11),kind=0)
    for i,p in enumerate(points,11):
        g.add_node(i,kind=1)
        g.add_edges_from((i,l) for l in p)
    return g

def certificate(points):
    import pynauty
    g=graph(points)
    ng=pynauty.Graph(len(g),adjacency_dict={i:list(g[i]) for i in g},vertex_coloring=[set(range(11)),set(range(11,len(g)))])
    return pynauty.certificate(ng)

def main():
    import networkx as nx
    started=time.perf_counter()
    names,base,remaining,cliques,extensions=enumerate_completions()
    allpoints=[base+list(e) for e in extensions]
    classes={}
    for i,ps in enumerate(allpoints):
        cover=Counter(e for p in ps for e in pairs(p))
        assert len(cover)==55 and set(cover.values())=={1}
        assert all(len(p&q)<=1 for p,q in combinations(ps,2))
        classes.setdefault(certificate(ps),[]).append(i)
    groups=sorted(classes.values(),key=lambda ids:(len(allpoints[ids[0]]),ids[0]))
    # Verify entire partition independently with VF2 graph isomorphism.
    match=nx.algorithms.isomorphism.categorical_node_match('kind',None)
    graphs=[graph(p) for p in allpoints]
    for ids in groups:
        for i in ids:
            assert nx.is_isomorphic(graphs[ids[0]],graphs[i],node_match=match)
    for a,b in combinations(groups,2):
        assert not nx.is_isomorphic(graphs[a[0]],graphs[b[0]],node_match=match)
    rows=[]
    for k,ids in enumerate(groups,1):
        ps=allpoints[ids[0]]
        lengths=[sum(l in p for p in ps) for l in range(11)]
        inc=sum(map(len,ps))
        rows.append(dict(class_id=k,labeled_count=len(ids),points=len(ps),incidences=inc,
                         rho12=inc+157-len(ps)-11*13,max_line_size=max(lengths),
                         point_line_sets=[sorted(p) for p in ps],labeled_members=ids))
    result=dict(scope='Standard nondegenerate nine-point, eleven-line Pappus failure; fixed line set; only intersection points retained',
                line_names=names,base_point_names=['a0','a1','a2','b0','b1','b2','c0','c1','c2'],
                base_point_line_sets=[sorted(p) for p in base],remaining_pairs=sorted(remaining),
                clique_sizes=dict(Counter(map(len,cliques))),labeled_completions=len(extensions),isomorphism_classes=len(groups),
                classes=rows,all_labeled_completions=[[sorted(p) for p in ps] for ps in allpoints],
                checks=['two independent completion enumerations agree','every line pair meets exactly once','no point pair lies on two lines','nauty partition independently verified by VF2'],
                seconds=time.perf_counter()-started)
    Path(__file__).with_name('catalogue.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('classes','all_labeled_completions')},indent=2))
    for r in rows: print({k:v for k,v in r.items() if k not in ('point_line_sets','labeled_members')})

if __name__=='__main__': main()
