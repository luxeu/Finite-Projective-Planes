# Six starting semiplanes from a standard failure of Pappus

Investigation date: 12 November 2026

## Result and scope

For the standard nondegenerate Pappus-failure configuration with nine distinct points and eleven distinct lines, there are **16 completions with the eleven lines labeled, and exactly six isomorphism classes of completed semiplanes**. Here completion means specifying all intersections among those same eleven lines, retaining exactly their intersection points. It does not mean extending to a full projective plane or adding more lines.

We obtained this result by exhaustive enumeration, verified it using a second enumeration and a separate isomorphism algorithm, and then derived the short counting argument below. This is a result of the present investigation, not a count quoted from Nation. Its originality is unconfirmed. The literature search did not locate this exact catalogue; unpublished calculations or a result under different terminology could exist.

Nation's 2019 paper, Section 5, suggests using the nine-point, eleven-line Pappus-failure configuration as a starting point. This investigation makes that particular suggestion concrete. It does not reproduce the additional kind of reduction used to pass from 105 Desargues-based classes to 15 unavoidable starting cases.

## 1. The starting configuration

Take three distinct points a0,a1,a2 on a line A, and three distinct points b0,b1,b2 on a different line B. None is A intersect B. Define the six cross-lines

    Lij = the line through ai and bj, for i != j.

For {i,j,k}={0,1,2}, define

    ci = Ljk intersect Lkj.

Pappus would say that c0,c1,c2 are collinear. We require them to be noncollinear and include their three distinct joining lines D01,D02,D12, where Dij joins ci to cj.

The fixed point incidences are:

| Point | Lines through it |
|---|---|
| a0 | A, L01, L02 |
| a1 | A, L10, L12 |
| a2 | A, L20, L21 |
| b0 | B, L10, L20 |
| b1 | B, L01, L21 |
| b2 | B, L02, L12 |
| c0 | L12, L21, D01, D02 |
| c1 | L02, L20, D01, D12 |
| c2 | L01, L10, D02, D12 |

No additional one of these eleven lines can pass through an existing one of these nine points. For each proposed extra incidence, at least one line already through that point has its intersection with the proposed line fixed at another point. Adding the incidence would make those two lines meet twice. This can be checked directly from the table; the program checks every such proposed incidence.

The original nine points also cannot be identified: pairs sharing a line cannot be merged without collapsing prescribed distinct intersections; equivalently, this investigation explicitly fixes the standard nine-distinct-point failure pattern. The results are a classification of that specified pattern, not an enumeration of arbitrary degenerate incidence diagrams sometimes called Pappus configurations.

## 2. Only nineteen intersections remain undecided

Eleven lines have 55 unordered pairs. Each a or b point fixes three pairs, and each c point fixes six pairs. These pairs are all different, so the fixed intersections account for

    6*3 + 3*6 = 36 pairs.

Thus 55-36=19 pairs still need intersection points. All these intersections must be new points.

Make a graph whose vertices are the eleven lines and whose edges are the nineteen unresolved pairs. Several lines can meet at one new point only if every pair among them is unresolved: they must form a complete subgraph (a clique). All edges of that clique then describe that one intersection point.

The full remaining edge list is supplied in catalogue.json. More descriptively, it consists of:

* AB and the six pairs A-Dij, B-Dij;
* the three pairs among L01,L12,L20;
* the three pairs among L02,L10,L21;
* L01-D01, L10-D01, L02-D02, L20-D02, L12-D12, L21-D12.

Inspection shows exactly five possible new triple intersections:

| Name | Three concurrent lines |
|---|---|
| U01 | A, B, D01 |
| U02 | A, B, D02 |
| U12 | A, B, D12 |
| V+ | L01, L12, L20 |
| V- | L02, L10, L21 |

There is no possible new point on four or more of the eleven lines. There are no other triangles in the remaining graph.

At most one U can be selected, since any two would give A and B two intersections. Either V can be selected independently of the other and independently of U. All unresolved pairs not used in selected triples get their own distinct two-line intersection point.

Consequently the exact labeled count is

    (no U, U01, U02, or U12) * (V+ absent/present) * (V- absent/present)
    = 4 * 2 * 2 = 16.

Every such selection gives a valid semiplane: each line pair occurs at exactly one point. Conversely every completion must make exactly one of these selections. This proves completeness for the stated scope.

## 3. Why there are exactly six isomorphism classes

Let t be 0 or 1 according as a U intersection is absent or present. Let k be 0, 1, or 2 according to the number of V intersections selected.

Simultaneously permuting the subscripts 0,1,2 on the a and b points permutes the three U choices. Interchanging the entire a and b triples exchanges V+ with V- while keeping the U choice fixed. These operations show that every selection with the same pair (t,k) is isomorphic. Hence there are at most six classes.

The table below distinguishes all six even when arbitrary point and line relabelings are permitted. The point count distinguishes different t+k. When that sum agrees, the maximum line size distinguishes t=0 from t=1. Thus the six types cannot collapse further.

| Catalogue ID | t | k | Labeled completions | Points | Incidences | Maximum points on a line | rho for order 12 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1 | 2 | 3 | 22 | 59 | 6 | 51 |
| 2 | 0 | 2 | 1 | 24 | 62 | 7 | 52 |
| 3 | 1 | 1 | 6 | 24 | 62 | 6 | 52 |
| 4 | 0 | 1 | 2 | 26 | 65 | 7 | 53 |
| 5 | 1 | 0 | 3 | 26 | 65 | 6 | 53 |
| 6 | 0 | 0 | 1 | 28 | 68 | 7 | 54 |

For a representative when t=1 choose U01; when k=1 choose V-; when k=2 choose both V's. Together with the fixed table and separate intersections for every uncovered pair, this specifies each representative completely.

The most separated case, ID 6, has nine fixed points and nineteen new two-line points: 28 points and 30+38=68 incidences. Each selected triple replaces three two-line points with one three-line point, reducing the point count by two and incidence count by three. With m=t+k:

    number of points = 28-2m;
    number of incidences = 68-3m.

These formulas independently check the catalogue's counts.

## 4. What the computation checked

The executable enumerate.py performs the following checks without assuming the answer 16 or six:

1. Generate every complete subgraph of the unresolved-pair graph and enumerate all edge partitions into such subgraphs, choosing the first uncovered pair at each step.
2. Independently enumerate subsets of the larger cliques, retaining edge-disjoint selections, and fill all remaining pairs with two-line points. Compare the actual completion sets, not just their counts.
3. Verify that each completed incidence structure has all 55 line pairs represented exactly once, and no pair of distinct points shares two lines.
4. Compute isomorphism classes using nauty through pynauty. Only the point/line distinction is colored; original point names and the original Pappus presentation are not preserved by the equivalence test.
5. Verify every member-to-representative equivalence and every pair of distinct representatives independently with NetworkX VF2 graph isomorphism.

All checks passed. Enumeration and classification, including these checks, took approximately 0.05 seconds in this run, excluding interpreter startup and dependency installation. The mathematical proof above makes this result independently assessable without trusting either graph package.

## 5. What this says about order 12

For these eleven-line semiplanes, Nation's necessary numerical condition is

    rho_12 = incidences + 157 - points - 11*13 = 54-m.

All six pass it. Their maximum point degree is four and maximum line size is at most seven, so all also satisfy the elementary degree and line-size caps of thirteen for order 12.

This supplies six explicit inputs for a possible extension search. It does not show that any input extends to order 12, nor that one is impossible. It does not establish that searches from these inputs are faster than searches from the Desargues-based inputs. A smaller initial catalogue can still lead to a larger extension tree.

The six classes are ordinary isomorphism classes. They have not been reduced under implications of the form 'every full plane containing class X also contains class Y.' Thus they should not be described as a proved minimal unavoidable set analogous to Nation-Seffrood's final 15.

## 6. Recommended next experiment

This first stage was substantially smaller than anticipated. A sensible next stage is a fixed-budget comparison of shallow extensions from these six representatives, using exactly the same extension rules, numerical checks, and symmetry handling as the existing implementation. Record labeled candidates, inequivalent surviving children, rejections, and runtime for each starting class. Validate that the existing search implementation accepts these general eleven-line inputs before comparing it with the old twelve-line inputs.

Do not infer order-12 nonexistence from a limited-depth search, and do not assume that fewer starting cases prove a speedup. For the informal paper, the present classification already offers a short, reproducible example of turning a geometric failure into a finite combinatorial enumeration.

Before describing this as new research, seek confirmation from Nation or another specialist that this elementary enumeration is not already known. No correspondence has been sent during this investigation.

## Reproducing and reading the files

Files in this package:

* REPORT.md: this explanation and counting proof.
* enumerate.py: executable enumeration and verification.
* catalogue.json: all sixteen labeled completions, their six classes, representatives, and statistics.
* requirements.txt: package versions used.

Run in a Python environment with the listed dependencies:

    python -m pip install -r requirements.txt
    python enumerate.py

The program writes catalogue.json alongside itself. The JSON stores each point as a list of incident line indices; line_names gives their interpretation. Its first nine points are a0,a1,a2,b0,b1,b2,c0,c1,c2. Subsequent points are unnamed intersections. Isomorphism respects points versus lines, not point-line duality.

## Sources and attribution

J. B. Nation, *Extending partial projective planes*, Algebra Universalis 80, article 7 (2019), especially Sections 4 and 5. DOI: https://doi.org/10.1007/s00012-019-0581-9. Author manuscript: https://math.hawaii.edu/~jb/extending_writeup_au_revised_2.pdf.

J. B. Nation and J. Seffrood, *Dual linear spaces generated by a non-Desarguesian configuration*, Contributions to Discrete Mathematics 6 (2011), 98-141. The comparison to its 105/15 classification is reported in Nation's 2019 paper. We have not rerun that classification as part of this investigation.

The six-class Pappus count, explicit representatives, proof, and computational validation in this report were derived in the present investigation. No claim of priority is made.
