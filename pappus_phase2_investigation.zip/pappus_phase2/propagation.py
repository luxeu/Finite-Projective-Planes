"""Force intersections of a mandatory new join with full old lines."""
from experiment import *
from bench import decode
def propagate(s,pair,ctx,n=12):
    compat,lines,full=ctx;(_,a,b),allowed=pair
    covered=s.supports[a]|s.supports[b];chosen=[a,b];trace=[]
    eligible=allowed
    for q in bits(allowed):
        if s.supports[q].bit_count()>=n+1:eligible &=~(1<<q)
    while True:
        rank=len(chosen)+s.line_count-covered.bit_count()
        if rank<n+1-s.rho(n):
            return {'rejected':True,'reason':'new_line_too_short','pair':[a,b],'chosen':chosen,'trace':trace,'maximum_rank':rank,'required_rank':n+1-s.rho(n)}
        forced=None
        for l,pm in full:
            if covered&(1<<l):continue
            options=pm&eligible
            if not options:return {'rejected':True,'reason':'uncovered_full_line','line':l,'pair':[a,b],'chosen':chosen,'trace':trace}
            if options.bit_count()==1:forced=(l,next(bits(options)));break
        if forced is None:return {'rejected':False,'chosen':chosen,'trace':trace}
        l,q=forced;trace.append({'line':l,'forced_point':q})
        assert not covered&s.supports[q]
        chosen.append(q);covered|=s.supports[q];eligible &= compat[q]

def verify(s,result,n=12):
    # Independently replay with Python sets rather than bit-mask contexts.
    ps=[set(bits(v)) for v in s.supports];a,b=result['pair']
    assert not ps[a]&ps[b];chosen={a,b};covered=ps[a]|ps[b]
    full={l:{p for p,v in enumerate(ps) if l in v} for l in range(s.line_count)}
    full={l:pm for l,pm in full.items() if len(pm)==n+1}
    def eligible():return {p for p,v in enumerate(ps) if len(v)<n+1 and not v&covered}
    for step in result['trace']:
        l,q=step['line'],step['forced_point']
        assert l in full and l not in covered
        assert full[l]&eligible()=={q}
        chosen.add(q);covered |= ps[q]
    if result['reason']=='uncovered_full_line':
        l=result['line'];assert l in full and l not in covered and not full[l]&eligible()
    else:assert len(chosen)+s.line_count-len(covered)<n+1-s.rho(n)
    return True

if __name__=='__main__':
    records=json.loads((ROOT/'corpus.json').read_text());out=[];counts=Counter();begin=time.perf_counter();elapsed=0
    for i,r in enumerate(records):
        s=decode(r['state']);ctx=context(s);bad,pair=singles(s,ctx)
        if bad or pair is None:continue
        t=time.perf_counter();answer=propagate(s,pair,ctx);elapsed+=time.perf_counter()-t
        if answer['rejected']:
            verify(s,answer);counts[r['seed'][0]]+=1
            out.append({'corpus_index':i,'seed':r['seed'],'state':r['state'],'certificate':answer})
    result={'states':len(records),'extra_rejections':dict(counts),'check_seconds_excluding_context':elapsed,'certificates':out}
    (ROOT/'propagation.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items() if k!='certificates'})
