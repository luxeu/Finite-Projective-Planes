"""Standalone verification of Pappus descendant and forced-intersection proof.
Python standard library only. Run: python verify_witness.py
"""
import json
from pathlib import Path
from itertools import combinations
from collections import Counter
def bits(v):return {i for i in range(v.bit_length()) if v&(1<<i)}
def check(raw):
    ps=[bits(v) for v in raw['supports']];m=raw['line_count']
    assert all(len(v)>=2 and max(v)<m for v in ps)
    pairs=Counter(e for v in ps for e in combinations(sorted(v),2))
    assert pairs==Counter({e:1 for e in combinations(range(m),2)})
    lines=[{p for p,v in enumerate(ps) if l in v} for l in range(m)]
    rho=sum(map(len,ps))+157-len(ps)-13*m
    assert len(ps)<=157 and m<=157 and rho>=0
    assert max(map(len,ps))<=13 and max(map(len,lines))<=13
    return ps,lines,rho
def main():
    root=Path(__file__).resolve().parent
    d=json.loads((root/'pappus_witness.json').read_text())
    path=d['path'];cat=json.loads((root/'pappus_catalogue.json').read_text())
    initial=next(r for r in cat['classes'] if r['class_id']==3)
    assert path[0]['supports']==[sum(1<<l for l in p) for p in initial['point_line_sets']]
    for raw in path:check(raw)
    for old,new in zip(path,path[1:]):
        m=old['line_count'];assert new['line_count']==m+1
        assert [v&((1<<m)-1) for v in new['supports'][:len(old['supports'])]]==old['supports']
        assert all(v&(1<<m) and v.bit_count()==2 for v in new['supports'][len(old['supports']):])
    ps,lines,rho=check(path[-1]);w=d['certificate'];a,b=w['pair']
    assert not ps[a]&ps[b];chosen={a,b};covered=ps[a]|ps[b]
    # Check every original simple required-join screen, independently.
    for x,y in combinations(range(len(ps)),2):
        if ps[x]&ps[y]:continue
        assert max(len(ps[x]),len(ps[y]))<13
        for l,points in enumerate(lines):
            if len(points)==13 and l not in ps[x]|ps[y]:
                assert any(not ps[q]&(ps[x]|ps[y]) for q in points)
    def eligible():return {q for q,v in enumerate(ps) if len(v)<13 and not v&covered}
    for step in w['trace']:
        l,q=step['line'],step['forced_point']
        assert len(lines[l])==13 and l not in covered
        assert lines[l]&eligible()=={q}
        chosen.add(q);covered|=ps[q]
    assert w['reason']=='uncovered_full_line'
    l=w['line'];assert len(lines[l])==13 and l not in covered
    assert not lines[l]&eligible()
    print('Verified: P3 ancestry, incidence axioms, all baseline screens, and forced-intersection contradiction.')
if __name__=='__main__':main()
