from experiment import *
from bench import witness,decode
from semiplane import independent_dp
def main():
    audit=json.loads((ROOT/'seed_audit.json').read_text());ss={k:decode(v) for k,v in audit['seeds'].items()}
    # Independent DP counts all compatible subsets; at seeds all numerical
    # bounds are inactive, so every subset yields an acceptable extension.
    census=json.loads((ROOT/'census.json').read_text())
    for row in census['rows']:
        s=ss[row['seed']];h=independent_dp(s.supports,s.line_count)
        assert sum(h.values())==row['labeled_children']
        for ch in children(s):ch.validate();assert not numeric(ch)
    raw=[set(map(int,line.split())) for line in (ROOT/'hall9.txt').read_text().splitlines() if line.strip()]
    assert len(raw)==91 and all(len(v)==10 for v in raw)
    lines=[{p for p,v in enumerate(raw) if l in v} for l in range(91)]
    assert all(len(x)==10 for x in lines)
    meets={};joins={}
    for p,v in enumerate(raw):
        for pair in combinations(sorted(v),2):assert pair not in meets;meets[pair]=p
    for l,v in enumerate(lines):
        for pair in combinations(sorted(v),2):assert pair not in joins;joins[pair]=l
    assert len(meets)==len(joins)==4095
    def join(a,b):return joins[tuple(sorted((a,b)))]
    def meet(a,b):return meets[tuple(sorted((a,b)))]
    def restriction(ls):
        ps={}
        for i,j in combinations(range(len(ls)),2):
            p=meet(ls[i],ls[j]);ps[p]=ps.get(p,0)|(1<<i)|(1<<j)
        return state(list(ps.values()),len(ls))
    target={cert(s):k for k,s in ss.items() if k.startswith('P')};found={};rng=random.Random(240811)
    for trial in range(20000):
        A,B=rng.sample(range(91),2);x=meet(A,B)
        a=rng.sample(sorted(lines[A]-{x}),3);b=rng.sample(sorted(lines[B]-{x}),3)
        cross={(i,j):join(a[i],b[j]) for i in range(3) for j in range(3) if i!=j}
        c=[meet(cross[j,k],cross[k,j]) for i in range(3) for j,k in [[v for v in range(3) if v!=i]]]
        if len(set(c))<3 or c[2] in lines[join(c[0],c[1])]:continue
        ls=[A,B]+list(cross.values())+[join(c[i],c[j]) for i,j in combinations(range(3),2)]
        assert len(set(ls))==11
        s=restriction(ls);key=cert(s);assert key in target
        found.setdefault(target[key],{'trial':trial,'hall_lines':ls})
        if len(found)==6:break
    assert len(found)==6,found
    checks=0
    for name,e in found.items():
        ls=e['hall_lines'];others=sorted(set(range(91))-set(ls));rng.shuffle(others)
        for length in [11,20,35,60,80,90,91]:
            s=restriction(ls+others[:length-11]);s.validate();assert not numeric(s,9)
            ctx=context(s,9);bad,pair=singles(s,ctx,9);assert not bad
            assert matching_reject(s,ctx,9) is None,(name,length)
            checks+=1
    # Compare full candidate sets with early pruning on/off, on feasible
    # and rejected descendants, and use true Hall extensions as positive checks.
    records=json.loads((ROOT/'corpus.json').read_text());comparisons=[]
    # Modest cases where exhaustive comparison is affordable.
    for r in records[::max(1,len(records)//20)]:
        s=decode(r['state'])
        if s.line_count>23:continue
        ctx=context(s);bad,pair=singles(s,ctx)
        if bad or pair is None:continue
        keys=[];stats=[]
        for early in [False,True]:
            st={};begin=time.perf_counter()
            keys.append({tuple(ch.supports) for ch in children(s,pair,stats=st,limit=100000,early=early)})
            stats.append({**st,'seconds':time.perf_counter()-begin})
        if not any(st['truncated'] for st in stats):assert keys[0]==keys[1]
        comparisons.append({'seed':r['seed'],'lines':s.line_count,'baseline':stats[0],'early_pruning':stats[1],'exhaustive':not any(st['truncated'] for st in stats),'children':[len(k) for k in keys]})
    out={'independent_DP_verified_seeds':21,'hall_embeddings':found,'hall_positive_control_states':checks,'generation_comparisons':comparisons}
    (ROOT/'validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
