"""Bounded exploration, rejection certificates, and paired search timings."""
from experiment import *

def encode(s):return {'supports':s.supports,'line_count':s.line_count}
def decode(d):return state(d['supports'],d['line_count'])
def witness(s,w,n=12):
    # Independently derive domains using incidence sets, then find an explicit
    # Hall-deficient subset. No reliance on the matching routine's execution.
    ps=[set(bits(v)) for v in s.supports];p=w['center'];a=w['anchor'];l=w['line']
    assert a not in ps[p] and l not in ps[p]
    anchor=[i for i,v in enumerate(ps) if a in v]
    assert len(anchor)==n+1
    slots={i for i in anchor if not ps[p]&ps[i]}
    qs=[i for i,v in enumerate(ps) if l in v and not ps[p]&v]
    ds={q:({q} if q in slots else {x for x in slots if not ps[q]&ps[x]}) for q in qs}
    for k in range(1,len(qs)+1):
        for subset in combinations(qs,k):
            union=set().union(*(ds[q] for q in subset))
            if len(union)<k:
                return {**w,'deficient_points':subset,'available_slots':sorted(union),'order':n}
    raise AssertionError('claimed rejection has no Hall witness')

def corpus(ss):
    records=[]
    for name,root in ss.items():
        for trial in range(4):
            rng=random.Random(1000+trial+sum(map(ord,name))*100)
            s=root
            for step in range(32):
                assert not numeric(s);s.validate()
                ctx=context(s);bad,pair=singles(s,ctx)
                records.append({'seed':name,'trial':trial,'step':step,'state':encode(s),'baseline_reject':bad})
                if bad or pair is None:break
                pool=[]
                for i,ch in enumerate(children(s,pair,limit=20000,early=False)):
                    pool.append(ch)
                    if i==255:break
                if not pool:break
                s=rng.choice(pool)
        print('corpus',name,len(records),flush=True)
        (ROOT/'corpus.json').write_text(json.dumps(records))
    return records

def static(records):
    counts=Counter(); times=Counter(); witnesses=[]
    for i,r in enumerate(records):
        s=decode(r['state']);t=time.perf_counter();ctx=context(s)
        bad,pair=singles(s,ctx);times['baseline_seconds']+=time.perf_counter()-t
        assert bad==r['baseline_reject'];counts['states']+=1;counts['baseline_reject']+=bad
        if bad:continue
        t=time.perf_counter();w=matching_reject(s,ctx);times['matching_extra_seconds']+=time.perf_counter()-t
        if w:
            counts['matching_extra_reject']+=1;counts[r['seed'][0]+'_matching_extra_reject']+=1
            witnesses.append({'corpus_index':i,'seed':r['seed'],'state':r['state'],'certificate':witness(s,w)})
    out={'counts':dict(counts),'times':dict(times),'witnesses':witnesses}
    (ROOT/'pruning.json').write_text(json.dumps(out,indent=2));print('pruning',counts,times,flush=True)
    return out

def search(root,extra,budget=100,early=True):
    counts=Counter();start=time.perf_counter()
    def dfs(s,depth):
        if counts['nodes']>=budget:return 'unknown'
        counts['nodes']+=1
        ctx=context(s);bad,pair=singles(s,ctx)
        if bad:counts['baseline_reject']+=1;return 'rejected'
        if extra and matching_reject(s,ctx):counts['matching_reject']+=1;return 'rejected'
        if depth==0 or pair is None:return 'unknown'
        unknown=False
        scan={}
        for ch in children(s,pair,stats=scan,limit=20000,early=early):
            counts['children']+=1
            ans=dfs(ch,depth-1)
            unknown|=ans=='unknown'
            if counts['nodes']>=budget:return 'unknown'
        counts['generation_visited']+=scan['visited']
        counts['generation_early_cuts']+=scan.get('early_cuts',0)
        if scan['truncated']:counts['generation_limits']+=1;unknown=True
        return 'unknown' if unknown else 'rejected'
    status=dfs(root,3)
    return {'status':status,'counts':dict(counts),'seconds':time.perf_counter()-start}

def paired(records,pruning):
    # Fixed predeclared rule: earliest deepest baseline-passing state per seed,
    # plus one separately identified diagnostic witness (not unbiased sample).
    roots=[]
    for name in sorted(set(r['seed'] for r in records)):
        options=[(i,r) for i,r in enumerate(records) if r['seed']==name and not r['baseline_reject']]
        i,r=max(options,key=lambda ir:(ir[1]['state']['line_count'],-ir[0]))
        roots.append((name,i,r['state'],'deepest_per_seed'))
    if pruning['witnesses']:
        w=pruning['witnesses'][0];roots.append(('diagnostic',w['corpus_index'],w['state'],'selected_rejection'))
    out=[]
    for name,i,raw,selection in roots:
        s=decode(raw);a=search(s,False,early=False);b=search(s,False,early=True);c=search(s,True,early=True)
        out.append({'seed':name,'corpus_index':i,'selection':selection,'baseline':a,'early_bounds':b,'early_bounds_and_matching':c})
        (ROOT/'paired.json').write_text(json.dumps(out,indent=2))
        print('paired',name,a,b,c,flush=True)
    return out

if __name__=='__main__':
    audit=json.loads((ROOT/'seed_audit.json').read_text())
    ss={k:decode(v) for k,v in audit['seeds'].items()}
    records=corpus(ss);p=static(records);paired(records,p)
