"""Necessary one-line completion test as a small binary packing problem.
Infeasibility rejects the state; feasibility certifies only this one line.
"""
from experiment import *
from bench import decode
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint

def solve_join(s,pair,n=12,integer=True,seconds=.25):
    (_,a,b),allowed=pair;ps=s.supports
    if max(ps[a].bit_count(),ps[b].bit_count())>n:return {'status':'infeasible'}
    eligible=[q for q in bits(allowed) if ps[q].bit_count()<n+1]
    covered=ps[a]|ps[b];m=s.line_count;ranks=s.ranks();rho=s.rho(n)
    initial_rank=m-covered.bit_count()+2
    rows=[];lower=[];upper=[]
    for l in range(m):
        if covered&(1<<l):continue
        rows.append([int(bool(ps[q]&(1<<l))) for q in eligible])
        lower.append(1 if ranks[l]==n+1 else 0);upper.append(1)
    rows.append([ps[q].bit_count()-1 for q in eligible])
    lower.append(max(0,initial_rank-(n+1)))
    upper.append(initial_rank-max(0,n+1-rho))
    if not eligible:
        ok=all(lo<=0<=hi for lo,hi in zip(lower,upper))
        return {'status':'feasible' if ok else 'infeasible','chosen':[a,b] if ok else None}
    if any(lo>hi for lo,hi in zip(lower,upper)):return {'status':'infeasible'}
    result=milp(np.zeros(len(eligible)),integrality=np.ones(len(eligible)) if integer else None,
        bounds=Bounds(np.zeros(len(eligible)),np.ones(len(eligible))),
        constraints=LinearConstraint(np.array(rows,dtype=float),lower,upper),options={'time_limit':seconds})
    if result.status==2:return {'status':'infeasible'}
    if result.x is not None and result.status==0:
        if integer:
            assert np.max(np.abs(result.x-np.round(result.x)))<1e-5
            chosen=[a,b]+[q for q,x in zip(eligible,result.x) if x>.5]
            ch=s.add_line(chosen)[0];ch.validate();assert not numeric(ch,n)
            return {'status':'feasible','chosen':chosen}
        return {'status':'fractionally_feasible'}
    return {'status':'unknown','solver_status':int(result.status)}

def run():
    data=json.loads((ROOT/'corpus.json').read_text());selected={}
    for i,r in enumerate(data):selected[r['seed'],r['trial']]=(i,r)
    out=[]
    # Warm up solver separately from timed runs.
    for i,r in list(selected.values())[:1]:
        s=decode(r['state']);_,pair=singles(s,context(s));solve_join(s,pair)
    for i,r in selected.values():
        s=decode(r['state']);bad,pair=singles(s,context(s));assert not bad
        row={'corpus_index':i,'seed':r['seed'],'trial':r['trial'],'lines':s.line_count,'rho12':s.rho(12)}
        for kind,integer in [('LP',False),('binary',True)]:
            t=time.perf_counter();row[kind]=solve_join(s,pair,integer=integer);row[kind]['seconds']=time.perf_counter()-t
        if row['binary']['status']=='infeasible':
            # Independent integer enumeration with safe bounds; a limit is
            # explicitly unknown, never a confirmation of infeasibility.
            st={};ch=next(children(s,pair,stats=st,limit=1000000),None)
            assert ch is None
            row['independent_enumeration']=st
        out.append(row);print(row,flush=True)
        (ROOT/'packing.json').write_text(json.dumps(out,indent=2))
    return out
if __name__=='__main__':run()
