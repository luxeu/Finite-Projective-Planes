import json, re, time, random
from pathlib import Path
from collections import Counter
from itertools import combinations
import pynauty
from semiplane import Semiplane, bits, choices, BASE_POINT_LINES
ROOT=Path(__file__).resolve().parent
def state(ps,m): return Semiplane(tuple('p'+str(i) for i in range(len(ps))),tuple(ps),m)
def cert(s,mark=None):
    m=s.line_count; n=len(s.supports)
    adj={i:[] for i in range(m+n)}
    for p,v in enumerate(s.supports,m):
        for l in bits(v): adj[p].append(l);adj[l].append(p)
    colors=[set(range(m)),set(range(m,m+n))]
    if mark is not None: colors=[set(range(m))-{mark},{mark},set(range(m,m+n))]
    return pynauty.certificate(pynauty.Graph(m+n,adjacency_dict=adj,vertex_coloring=colors))
def numeric(s,n=12):
    return s.line_count>n*n+n+1 or len(s.supports)>n*n+n+1 or s.rho(n)<0 or any(v.bit_count()>n+1 for v in s.supports) or max(s.ranks())>n+1
def seeds():
    base=[sum(1<<(l-1) for l in p) for p in BASE_POINT_LINES]
    old={'I1':(7,0),'I2':(9,1),'I3':(8,2),
         'II1a':(5,3),'II1b':(4,4),'II1c':(3,5),
         'II2a':(2,6),'II2b':(1,7),'II2c':(0,8),
         'II3a':(6,9),'II3b':(6,10),'II3c':(6,11)}
    triple={k:sum(1<<(l-1) for l in v) for k,v in zip(['IIIa','IIIb','IIIc','IIId','IIIe','IIIf'],[(1,6,11),(1,9,11),(2,5,10),(2,8,10),(3,4,12),(3,7,12)])}
    def build(ops):
        ps=base.copy()
        for op in ops:
            if op in old:
                p,l=old[op];ps[p]|=1<<l
            elif op in triple:ps.append(triple[op])
        seen=set()
        for v in ps:
            for pair in combinations(bits(v),2):
                if pair in seen:return None
                seen.add(pair)
        for a,b in combinations(range(12),2):
            if (a,b) not in seen:ps.append((1<<a)|(1<<b))
        return state(ps,12)
    # Reconstruct all published representatives and check all point/rho claims.
    allreps={}; metadata=[]
    if (ROOT/'nation_seffrood.txt').exists():
        text=(ROOT/'nation_seffrood.txt').read_text()
        definitions=re.findall(r'Class (\d+)\. Semiplanes? with (\d+)(?: points)? and ρ12 = (\d+)\.\s*\(a\) ([Iabcde f123,]+)',text)
    else:
        definitions=[(r['id'],r['points'],r['printed_rho12'],','.join(r['operations'])) for r in json.loads((ROOT/'seed_audit.json').read_text())['published_representatives']]
    for num,pts,rho,ops in definitions:
        ops=ops.strip().replace(' ','').split(','); s=build(ops)
        assert s is not None,(num,ops)
        s.validate();assert len(s.supports)==int(pts),(num,len(s.supports),pts)
        allreps[int(num)]=s;metadata.append({'id':int(num),'operations':ops,'points':int(pts),'printed_rho12':int(rho),'computed_rho12':s.rho(12)})
    assert len(allreps)==105,len(allreps)
    assert len({cert(s) for s in allreps.values()})==105
    # Enumerate all consistent subsets of the paper's 18 incidence operations.
    ops=list(old)+list(triple); valid=[]
    def rec(i,selected):
        s=build(selected)
        if s is None:return
        if i==len(ops):valid.append(s);return
        rec(i+1,selected);rec(i+1,selected+[ops[i]])
    rec(0,[])
    assert len(valid)==875,len(valid)
    assert {cert(s) for s in valid}=={cert(s) for s in allreps.values()}
    target=[1,2,6,11,12,20,24,25,32,33,46,63,64,73,74]
    assert all(r['printed_rho12']==r['computed_rho12'] for r in metadata if r['id'] in target)
    out={'D'+str(i):allreps[i] for i in target}
    cat=json.loads((ROOT/'pappus_catalogue.json').read_text())
    for r in cat['classes']:
        s=state([sum(1<<l for l in p) for p in r['point_line_sets']],11);s.validate()
        out['P'+str(r['class_id'])]=s
    (ROOT/'seed_audit.json').write_text(json.dumps({'desargues_labeled':875,'desargues_classes':105,'published_representatives':metadata,'selected':target,'seeds':{k:{'supports':s.supports,'line_count':s.line_count} for k,s in out.items()}},indent=2))
    return out

def context(s,n=12):
    ps=s.supports; pcount=len(ps)
    compat=[sum(1<<j for j,w in enumerate(ps) if not v&w) for v in ps]
    lines=[sum(1<<p for p,v in enumerate(ps) if v&(1<<l)) for l in range(s.line_count)]
    full=[(l,mask) for l,mask in enumerate(lines) if mask.bit_count()==n+1]
    return compat,lines,full
def singles(s,ctx,n=12):
    compat,lines,full=ctx; best=None
    for a,ca in enumerate(compat):
        if ca and s.supports[a].bit_count()>=n+1:return True,None
        for b in bits(ca&~((1<<(a+1))-1)):
            allowed=ca&compat[b]
            for l,pm in full:
                if not (s.supports[a]|s.supports[b])&(1<<l) and not pm&allowed:return True,None
            key=(allowed.bit_count(),a,b)
            if best is None or key<best[0]:best=(key,allowed)
    return False,best
def matching_reject(s,ctx,n=12):
    """Hall matching at a full anchor; no complete coloring search.
    Every tested family consists of points on one old line, unjoined to p.
    A matching failure is a sound obstruction. No rejection means only pass.
    """
    compat,lines,full=ctx
    for p,v in enumerate(s.supports):
        r=n+1-v.bit_count()
        if r>6:continue # performance gate, weakens only detection
        for anchor,pm in full:
            if v&(1<<anchor):continue
            slots=pm&compat[p]
            assert slots.bit_count()==r
            for l,qm in enumerate(lines):
                if l==anchor or v&(1<<l):continue
                qs=list(bits(qm&compat[p]))
                if len(qs)<2:continue
                domains={q: ((1<<q) if slots&(1<<q) else slots&compat[q]) for q in qs}
                match={}
                def augment(q,seen):
                    for x in bits(domains[q]):
                        if x in seen:continue
                        seen.add(x)
                        if x not in match or augment(match[x],seen):match[x]=q;return True
                    return False
                for q in sorted(qs,key=lambda q:domains[q].bit_count()):
                    if not augment(q,set()):
                        return {'center':p,'anchor':anchor,'line':l,'slots':list(bits(slots)),'domains':{str(q):list(bits(d)) for q,d in domains.items()}}
    return None

def children(s,pair=None,n=12,stats=None,limit=None,early=True,forced=None):
    ps=s.supports;m=s.line_count; ranks=s.ranks();rho=s.rho(n)
    fullmask=sum(1<<l for l,r in enumerate(ranks) if r==n+1)
    eligible=[i for i,v in enumerate(ps) if v.bit_count()<n+1]
    if pair:
        (_,a,b),allowed=pair
        if a not in eligible or b not in eligible:return
        selected=tuple(forced) if forced is not None else (a,b)
        assert a in selected and b in selected
        covered=0
        for p in selected:
            assert not covered&ps[p];covered |= ps[p]
        eligible=[i for i in eligible if allowed&(1<<i) and not covered&ps[i]]
    else:selected=();covered=0
    if stats is None:stats={}
    stats['visited']=0;stats['truncated']=False
    suffix=[0]*(len(eligible)+1)
    for j in range(len(eligible)-1,-1,-1):suffix[j]=suffix[j+1]|ps[eligible[j]]
    def rec(start,cov,sel):
        if limit is not None and stats['visited']>=limit:
            stats['truncated']=True;return
        stats['visited']+=1
        size=len(sel)+m-cov.bit_count()
        if early and (size<n+1-rho or fullmask&~(cov|suffix[start])):
            stats['early_cuts']=stats.get('early_cuts',0)+1;return
        if 0<=n+1-size<=rho and not fullmask&~cov:
            yield s.add_line(sel)[0]
        for j in range(start,len(eligible)):
            if stats['truncated']:return
            q=eligible[j]
            if not cov&ps[q]:yield from rec(j+1,cov|ps[q],sel+(q,))
    yield from rec(0,covered,selected)

def census(ss):
    rows=[]; childsets={}; totals={}
    for name,s in ss.items():
        t=time.perf_counter(); unmarked=set();marked=set();count=0
        for ch in children(s):
            assert not numeric(ch)
            count+=1;unmarked.add(cert(ch));marked.add(cert(ch,ch.line_count-1))
        childsets[name]=unmarked
        row={'seed':name,'initial_lines':s.line_count,'points':len(s.supports),'rho12':s.rho(12),'labeled_children':count,'parent_orbits':len(marked),'unmarked_children':len(unmarked),'seconds':time.perf_counter()-t}
        rows.append(row);print('census',row,flush=True)
    for family in ['P','D']:
        keys=[k for k in ss if k.startswith(family)]
        totals[family]={'labeled':sum(r['labeled_children'] for r in rows if r['seed'] in keys),'sum_parent_orbits':sum(r['parent_orbits'] for r in rows if r['seed'] in keys),'union_unmarked':len(set().union(*(childsets[k] for k in keys)))}
    result={'rows':rows,'totals':totals,'P_children_equal_selected_D_seeds':{k:[d for d in ss if d.startswith('D') and cert(ss[d]) in childsets[k]] for k in ss if k.startswith('P')}}
    (ROOT/'census.json').write_text(json.dumps(result,indent=2));return result

if __name__=='__main__': census(seeds())
