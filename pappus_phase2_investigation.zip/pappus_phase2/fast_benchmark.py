from experiment import *
from bench import decode
from propagation import propagate,verify

def one(s,mode,limit=20000,n=12):
    ctx=context(s,n);bad,pair=singles(s,ctx,n)
    if bad or pair is None:return {'status':'baseline_reject' if bad else 'no_missing_pair'}
    t=time.perf_counter();forced=None
    if mode=='propagation':
        answer=propagate(s,pair,ctx,n)
        if answer['rejected']:
            verify(s,answer,n)
            return {'status':'rejected','seconds':time.perf_counter()-t,'visited':0}
        forced=answer['chosen']
    st={};ch=next(children(s,pair,n=n,stats=st,limit=limit,early=mode!='original',forced=forced),None)
    elapsed=time.perf_counter()-t
    if ch is not None:ch.validate();assert not numeric(ch,n)
    return {'status':'found_line' if ch else ('unknown' if st['truncated'] else 'rejected'),'seconds':elapsed,**st}

def main():
    corpus=json.loads((ROOT/'corpus.json').read_text());selected={}
    for i,r in enumerate(corpus):selected[r['seed'],r['trial']]=(i,r)
    out=[]
    for i,r in selected.values():
        s=decode(r['state']);row={'corpus_index':i,'seed':r['seed'],'trial':r['trial'],'lines':s.line_count}
        for mode in ['original','early_bounds','propagation']:row[mode]=one(s,mode)
        out.append(row)
    (ROOT/'fast_benchmark.json').write_text(json.dumps(out,indent=2))
    for mode in ['original','early_bounds','propagation']:
        print(mode,Counter(r[mode]['status'] for r in out),sum(r[mode].get('seconds',0) for r in out),sum(r[mode].get('visited',0) for r in out),flush=True)
    # Positive controls: full lines sampled from an actual Hall plane, and
    # enumeration equivalence before/after forcing on bounded tractable cases.
    raw=[set(map(int,line.split())) for line in (ROOT/'hall9.txt').read_text().splitlines() if line.strip()]
    rng=random.Random(519);positive=0;comparisons=[]
    for length in [11,20,35,60,80,90]:
        for trial in range(4):
            ls=rng.sample(range(91),length)
            ps=[sum(1<<j for j,l in enumerate(ls) if l in v) for v in raw]
            s=state([v for v in ps if v.bit_count()>=2],length)
            assert not numeric(s,9)
            ctx=context(s,9);bad,pair=singles(s,ctx,9);assert not bad
            if pair:
                ans=propagate(s,pair,ctx,9);assert not ans['rejected'];positive+=1
    # Verify equality of COMPLETE child sets whenever both enumerations finish.
    for i,r in list(selected.values())[:12]+[x for x in selected.values() if x[1]['seed'].startswith('P')][:8]:
        s=decode(r['state']);ctx=context(s);bad,pair=singles(s,ctx);ans=propagate(s,pair,ctx)
        if ans['rejected']:verify(s,ans);continue
        keys=[];statistics=[]
        for force in [None,ans['chosen']]:
            st={};keys.append({tuple(ch.supports) for ch in children(s,pair,stats=st,limit=200000,forced=force)})
            statistics.append(st)
        # Construction uses original point order regardless of selection order.
        if not any(st['truncated'] for st in statistics):assert keys[0]==keys[1]
        comparisons.append({'corpus_index':i,'statistics':statistics,'children':[len(x) for x in keys],'complete':not any(st['truncated'] for st in statistics)})
    (ROOT/'propagation_validation.json').write_text(json.dumps({'positive_Hall_controls':positive,'complete_set_comparisons':comparisons},indent=2))
if __name__=='__main__':main()
