# Pappus classification: audit, comparison, and pruning experiments

## Main findings

There are exactly six isomorphism classes in the specified initial family: completions of the standard nine-point, eleven-line failure of Pappus, without adding lines. There are many more classes after extension. Adding one line gives 989 distinct twelve-line semiplanes across the six seeds. None of those 989 is isomorphic to one of the fifteen selected Desargues seeds.

The first experiment's six-class count should therefore never be described as six classes of all partial projective planes, or six remaining cases for a small exhaustive order-12 computation. It is a complete classification at one particular starting stage. Whether it is already known remains unconfirmed.

The useful computational development in this phase is a combination of early numerical bounds and forced-intersection propagation. The former substantially improves candidate generation on this sample. The latter supplies small, independently checked rejection certificates, including one on an actual descendant of Pappus class P3. A more elaborate matching test gave no additional rejections in the sampled corpus.

## 1. Auditing the classifications

Pappus seed IDs P1 through P6 are the IDs of the previous catalogue. Their point counts are 22,24,24,26,26,28 respectively. They are six isomorphism types, not a proved minimal unavoidable set under implications between different configurations in a whole plane.

As a positive control, we found all six as actual eleven-line restrictions of the supplied Hall plane of order nine. This verifies that none is an inherently contradictory incidence structure. It does not imply that they extend to order twelve. The Hall embeddings, with exact line indices, are in validation.json.

For the comparison, we reconstructed the original Desargues pattern and all eighteen optional incidence operations in Nation-Seffrood's paper. Exhaustive enumeration reproduced 875 labeled completions and exactly 105 isomorphism classes. The 105 representatives reconstructed from the paper's appendix give exactly the same set of certificates. We selected the fifteen classes of its Theorem 12:

    1, 2, 6, 11, 12, 20, 24, 25, 32, 33, 46, 63, 64, 73, 74.

These have names D1, D2, etc. We reproduced the 875-to-105 enumeration, but did not reprove the geometric implication argument reducing 105 to fifteen.

All 105 reconstructed point counts match the appendix. Three printed rho values in the author manuscript differ from direct calculation: class 34 prints 45 versus computed 47; class 55 prints 47 versus computed 43; class 99 prints 43 versus computed 42. None is among the selected fifteen, whose point counts and rho values all match. The discrepancies are retained explicitly in seed_audit.json rather than silently corrected. They should be checked against the final journal version before being called publication errors.

## 2. Exact first-extension census

The same extension routine and the same numerical bounds were used for both families, with target order twelve. Every pairwise-compatible subset of existing points was considered, including empty and singleton subsets. This is an unrestricted one-line census, not the later mandatory-pair search policy. All these first-step candidates pass the numerical bounds.

| Starting seed | Points | Labeled children | Children modulo parent symmetries |
|---|---:|---:|---:|
| P1 | 22 | 316 | 99 |
| P2 | 24 | 448 | 65 |
| P3 | 24 | 509 | 283 |
| P4 | 26 | 742 | 162 |
| P5 | 26 | 836 | 239 |
| P6 | 28 | 1,248 | 143 |
| Total before cross-parent deduplication | | 4,099 | 991 |

The 991 counts reduce to 989 after identifying isomorphic children across different Pappus parents. Thus P2 has more labeled extensions than P1 but fewer inequivalent extensions, illustrating why symmetry matters.

| Family | Starting lines | Seeds | Labeled one-line children | Distinct children across family |
|---|---:|---:|---:|---:|
| Pappus | 11 | 6 | 4,099 | 989 at 12 lines |
| Desargues reduced set | 12 | 15 | 22,776 | 9,022 at 13 lines |

The sum of parent-symmetry orbits for the Desargues set is 9,044. Detailed results for all fifteen seeds are in census.json. As another independent check, an include/exclude dynamic program reproduced each of the 21 labeled child counts. Every generated first-step child was checked for incidence consistency and the numerical conditions.

### Comparison at a common depth

Starting from one representative of each of the 989 twelve-line Pappus descendants, an exact compatible-subset count gives **1,432,920 labeled extensions to thirteen lines**. Starting from the fifteen twelve-line Desargues seeds gives **22,776**, about 63 times fewer candidates under this enumeration convention.

These are candidate-processing counts, not counts of distinct thirteen-line planes. The Pappus descendants' thirteen-line children were not all classified up to isomorphism. The counts also do not predict total search time. They do show why six starting configurations are not automatically computationally preferable to fifteen configurations one line further along. The geometric reduction behind the published fifteen may be more valuable than the smaller raw Pappus catalogue.

## 3. Search corpus and limits

We generated four deterministic trajectories from each of the 21 seeds, for 84 trajectories and 2,073 recorded states. States ranged from 11 to 41 lines. At each step the search chose an unjoined pair of points with the fewest common compatible points, examined at most 20,000 compatible-subset recursion nodes, collected at most the first 256 legal children, and selected one using a recorded deterministic random seed. Each trajectory was limited to 32 recorded states.

This is an intentionally bounded convenience sample, not a uniform sample of semiplanes. A generation limit is recorded as inconclusive; it is never interpreted as nonextendibility. The corpus was generated with the original subset enumeration before the new early bounds or propagation were enabled. The file corpus.json preserves the actual states so later comparisons use the same inputs.

The baseline checks were incidence consistency, the point and line caps, nonnegative rho, the saturated-point check, and a simple required-join screen: every full old line disjoint from a required pair must contain at least one point that can join both endpoints. All 2,073 recorded states passed these checks.

## 4. The effective checks

### A. Early bounds during generation

Suppose m old lines are present and a new line uses a compatible set S of existing points. If C is the set of old lines incident with S, its current final size would be

    r_new = |S| + m - |C|.

For order twelve it must satisfy

    13 - rho <= r_new <= 13.

Adding another compatible existing point q changes this size by 1-degree(q), which is negative because retained points have degree at least two. Consequently, once a partial choice drops below 13-rho, no further selection can rescue it. We stop that branch immediately. We also stop if an uncovered full old line has no possible covering point anywhere in the remaining suffix of choices.

These are sound implementation shortcuts for existing necessary conditions. They are not a newly stronger geometric condition. They preserve the complete set of accepted children when enumeration is allowed to finish.

### B. Forced intersections with full lines

Take two existing points a,b with no joining line yet. Every completion to a projective plane must contain their join J. If an existing line L already has all thirteen points, J must meet L at one of them. New intersection points on L are forbidden.

If only one point q on L remains compatible with everything already forced onto J, then q must also lie on J. Selecting q can rule out points on other full lines, creating more forced choices. Reject if a full line loses every option, or if forced choices make the prospective new line too short to preserve nonnegative rho.

This differs from the earlier coloring test: it is repeated propagation for one required join. It can be expressed as elementary unit propagation in a one-line extension constraint problem. It is not asserted to be a new theorem or unknown technique.

Across the 2,073 baseline-passing states, it rejected eight: seven Desargues descendants and one Pappus descendant. The additional propagation work took approximately 0.037 seconds total, excluding the existing context construction and pair-selection work. Each rejection has an explicit certificate independently replayed using set-based incidence calculations.

### C. Matching and solver experiments

The anchored matching test fixes a full line as possible destinations for future lines through a point. Points on another old line must occupy distinct destinations. A failed bipartite matching would be a sound Hall obstruction. The implementation tested centers with at most six remaining line slots.

It found **zero extra rejections** in the 2,073-state sample and added approximately 1.60 seconds beyond the baseline screening work. We therefore leave it out of the recommended default checks.

We also formulated the feasibility of a required join as a binary packing problem: an optional point is either on the new line or not, no old line may be met twice, every full old line must be covered, and the new-line-size/rho inequalities must hold. On the 84 final trajectory states, both the linear relaxation and binary solver rejected the same eight states caught by propagation. The binary solver supplied valid next lines for the other 76. Every returned line was checked directly. Every solver rejection was independently confirmed by complete integer enumeration; all eight verification enumerations finished, taking only 170 to 410 recursive nodes each after early bounds.

There is no evidence in this sample that the solver adds pruning beyond propagation. It is potentially useful as a fallback for finding a next line when subset generation hits a limit, but we do not recommend it as an obligatory rejection test at every node.

## 5. A concrete Pappus-descendant obstruction

The witness is corpus entry 1703: trajectory 1 from P3, after reaching 36 lines. It has rho_12=0 and passes all the baseline screens. Point and line indices below are zero-based indices in the supplied state, not the original diagram's labels.

The missing join of points 0 and 87 forces, successively:

| Full old line | Forced point on the new join |
|---:|---:|
| 1 | 94 |
| 8 | 57 |
| 5 | 62 |
| 7 | 49 |
| 14 | 68 |
| 11 | 74 |
| 4 | 79 |
| 12 | 146 |
| 10 | 42 |

After these forced choices, full line 25 has no possible intersection with the required join. This is a contradiction. No guess about future lines is needed. The complete state, certificate, and path from P3 are supplied in pappus_witness.json. Its certificate can be checked without a graph package or optimization solver.

The rejection applies to this particular descendant, not to seed P3 or to all planes of order twelve. An exhaustive extension search would eventually discover the same failure. Propagation detects it before enumerating the alternatives for that required join.

## 6. Fixed-budget candidate-generation benchmark

We used the final state of each of the 84 trajectories. For each state the task was to find one legal next line through the same required pair, or exhaust the possibilities. Each generator had the same limit of 20,000 recursive nodes. Timing excludes the common context construction and required-pair selection.

| Method | Found a legal line | Proved required join impossible | Inconclusive at limit | Total seconds |
|---|---:|---:|---:|---:|
| Original enumeration | 0 | 8 | 76 | 1.230 |
| Early bounds | 75 | 8 | 1 | 0.337 |
| Early bounds plus propagation | 75 | 8 | 1 | 0.352 |

For the Pappus subset alone, the corresponding outcomes are 0/1/23 for the original generator and 23/1/0 for both improved versions. The early-bound Pappus run took about 0.104 seconds versus 0.373 seconds for the original run.

These are single-run timings on this environment, not robust hardware-independent speedup estimates. The methods perform different amounts of useful search before their caps, so the strongest conclusion is the improvement in outcomes at a fixed enumeration budget. Adding propagation did not produce a measured overall runtime improvement over early bounds alone in this benchmark. Its advantages are explicit certificates and early diagnosis at very small added cost.

The separate depth-three comparison in paired.json used at most 100 state visits and 20,000 generation recursion nodes per expansion on the deepest baseline-passing state from each seed. Early bounds let the search do much more work, so total times are not directly comparable: original enumeration resolved 1 of 21 roots, early bounds resolved 2, and matching resolved no additional roots. This experiment must not be presented as a clean wall-time speedup.

## 7. Validation and recommended defaults

Validation includes:

* Reproduction of the 875/105 Desargues census, with all 105 appendix representatives matching.
* All 21 first-extension counts independently checked by dynamic programming.
* All six Pappus types found in a real Hall plane of order nine.
* Numerical, simple-screen, and matching checks accepted 42 Hall-plane restrictions.
* Propagation accepted another 24 Hall-plane restrictions.
* Every claimed propagation rejection independently replayed from its certificate.
* All eight solver rejections confirmed by complete integer enumeration.
* Exact child-set equality with early pruning on/off on ten completed comparisons; child-set equality with forced points included/excluded on six completed comparisons. Capped comparisons are separately marked and do not count as equality proofs.

Recommended order: numerical checks; the simple full-line/saturated-point screen; forced-intersection propagation on the selected required pair; candidate generation with early rho and coverage bounds. The matching routine and general solver remain optional experiments. A pass always means only that the tested necessary conditions did not reject the state.

The public entry points are assess and extensions in checks.py. The latter's stats reports a generation cutoff; callers must treat a cutoff as unknown even if no child was yielded. The selected mandatory pair is justified because any completed projective plane must contain its unique joining line. Moving that line earlier in an extension sequence preserves completeness of this branching choice.

A useful next research target is a broader reproducible comparison of mandatory-pair selection policies and symmetry reduction at equal line counts. The present evidence does not justify replacing the published fifteen Desargues seeds wholesale, or claiming a new obstruction to order twelve.

## Files and reproduction

Install requirements.txt in a suitable Python environment. The experiments used Python 3.12, pynauty 2.8.8.1, NetworkX 3.7 and SciPy 1.17.0. Core propagation and certificate verification use integer bit masks and sets; graph and solver dependencies are for classification and optional experiments.

    python experiment.py       # audit and exact first-extension census
    python controls.py         # DP and Hall positive controls
    python propagation.py      # replay inexpensive rejection checks on corpus
    python fast_benchmark.py   # fixed-budget generator comparison
    python packing.py          # optional LP/binary feasibility comparison

bench.py regenerates the deterministic corpus and the longer depth-three comparisons. Existing results are included; rerunning rewrites their JSON files. experiment.py uses supplied mathematical representative definitions in seed_audit.json if the original paper's extracted text is absent.

common_depth.json records the exact equal-depth candidate counts; its generating script is common_depth.py. The initial six-class enumeration and proof are included under initial_classification/. No solver output or capped search is used as proof of existence of a full plane.

## Sources

J. B. Nation and Jiajia Y. G. Seffrood, *Dual linear spaces generated by a non-Desarguesian configuration*, Contributions to Discrete Mathematics 6 (2011), 98-141. DOI https://doi.org/10.55016/ojs/cdm.v6i1.62078. Author manuscript used for reconstruction: https://math.hawaii.edu/~jb/planes-cdm.pdf, Tables 1-2, Sections 3-7 and appendix. The paper's original tests and exhaustive extension algorithm would eventually discover the one-line obstructions reported here.

J. B. Nation, *Extending partial projective planes*, Algebra Universalis 80, article 7 (2019), https://doi.org/10.1007/s00012-019-0581-9, Section 5. Author manuscript https://math.hawaii.edu/~jb/extending_writeup_au_revised_2.pdf.

Hall-plane incidence data: G. Eric Moorhouse's finite-plane collection, https://ericmoorhouse.org/pub/planes/hall9.txt, reused from the earlier project's validated control data. The full 91-point incidence axioms were independently checked again here.
