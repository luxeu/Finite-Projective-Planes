from experiment import *
from bench import decode
def main():
    ss={k:decode(v) for k,v in json.loads((ROOT/'seed_audit.json').read_text())['seeds'].items() if k.startswith('P')}
    parents={}
    for s in ss.values():
        for ch in children(s):parents.setdefault(cert(ch),ch)
    t=time.perf_counter();rows=[]
    for i,s in enumerate(parents.values()):
        rows.append({'parent':i,'points':len(s.supports),'labeled_children':sum(1 for _ in choices(s.supports))})
    d=json.loads((ROOT/'census.json').read_text())['totals']['D']['labeled']
    out={'P_distinct_12_line_parents':len(rows),'P_labeled_extensions_from_these_parents_to_13_lines':sum(r['labeled_children'] for r in rows),'D_labeled_extensions_from_15_parents_to_13_lines':d,'seconds':time.perf_counter()-t,'note':'Counts distinguish parents and old line labels; not distinct 13-line isomorphism classes.','rows':rows}
    (ROOT/'common_depth.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
